# What works

Version 2.0 · Effective November 11, 2026

## Devices and pairing

iPhone and iPad with iOS/iPadOS 17 or later. Local IPv4 Wi-Fi and modern sender browsers. Local-command and whole-screen receivers stay open in the foreground. Compatible native streams can use audio background mode or native Picture in Picture; this does not keep the receivers alive. Bonjour announces Still’s own service; it does not create a YouTube Cast target.

## Video sources

YouTube watch, youtu.be, Shorts and live-video links that allow embedding. Direct HTTPS MP4, MOV, M4V, MP3, M4A and HLS (.m3u8) URLs with iOS-compatible codecs. Query-string access tokens are supported. Playlist pages, arbitrary web pages, custom authenticated headers and local HTTP media are not supported.

## Playback and session tools

Play/pause, seeking where supported, player volume, native stream full screen, queue of up to 20 items, queue editing, auto-next, repeat current video, supported playback speeds, skip intervals, HLS quality ceilings, session sleep timer and queue-only remotes. YouTube quality is managed by YouTube. Live media may lack a seekable timeline. Native Picture in Picture is available through supported stream-player controls, and background stream audio is optional. Still provides no background receiver service.

## Privacy and personalization

Five adaptive color themes, system/light/dark appearance, compact spacing, optional supported-device haptics, screen-awake setting, YouTube playback switch, no automatic analytics, offline legal search, safe user-shared support summary and local wipe.

## Unavailable protocols

No certified Google Cast receiver, YouTube Cast-menu discovery, AirPlay receiving, Miracast, DRM bypass, YouTube downloading, public exposure of the local HTTP command server or IPv6-only local-link pairing. Optional WebRTC screen-sharing invitations can work over the internet with deployed HTTPS and TURN services. No promise that all provider videos support embedding, speed, seeking or quality changes.

## Whole-screen video

Android 10+ with the Still Android app and system capture consent; compatible desktop browsers using HTTPS getDisplayMedia. WebRTC video-only reception, adaptive quality profiles, bounded reconnect attempts and opt-in local video recording. Internet sharing needs a deployed connection service, valid HTTPS and usually TURN. Android and desktop capture may continue while other apps are used, under OS rules. Receiving on iPhone/iPad remains foreground only. Android and supported desktop hosts can grant control for the current session. iOS hosts cannot grant remote input. Microphone and system audio are not captured; protected content may be black.

## Version 2 platform behavior

iOS/iPadOS 17+: foreground viewer/controller and user-started video-only ReplayKit broadcaster; no remote control of iOS. Android 10+: sender and viewer together, full-display MediaProjection consent, optional Accessibility gestures for the active session. macOS, Windows and Linux: Electron desktop sender and viewer together, optional native pointer/selected-key input; macOS permissions required, Linux input limited to X11, Windows secure prompts unavailable. Desktop signing/notarization and store distribution are separate release tasks. The supplied source needs a configured HTTPS connection service and TURN for many networks. No zero-latency or always-connected guarantee.
