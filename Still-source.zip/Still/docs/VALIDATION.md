# Validation record · Still 2.0

Validated in the Linux authoring workspace on November 11, 2026:

- Full Android Gradle 8.13 / JDK 17 / Android SDK 36 **assembleDebug + lintDebug passed** after adding the native viewer, Accessibility service, sender-owned invitations and light/dark appearance. This produces a debug APK; it does not validate actual capture consent, gestures or vendor background behavior on a device.
- **29 Node tests passed**: nine local browser-remote tests, six offline-document/notice consistency checks, ten relay tests and four desktop input/adapter/invitation validation tests. Relay coverage includes owner/invitation authentication, one-viewer limits, role enforcement, sender-owned rooms, host capability revocation, reconnect, recording consent, temporary TURN credentials, origin rejection and bounded malformed input. Native-input validation rejects out-of-range/nonfinite gestures, arbitrary keys and command messages.
- Browser WebRTC integration passed using actual encoded/decoded video through an isolated loopback TURN/TCP relay: simultaneous sharing and viewing in two desktop renderer pages, data-channel delivery of an approved click, recording consent flags, stop revocation, dark appearance and offline policy display. Capture and the native-input destination were explicit canvas/collector fixtures, not actual screen capture or OS input.
- Legacy browser sender integration passed: explicit capture action, video frames, private fragment removal, recording notice, receiver reconnect without recapture, mobile layout and stop cleanup. Capture was a canvas fixture.
- Real Electron 45.3.0 headless runtime smoke test passed: sandboxed preload, context isolation, nodeIntegration disabled, offline legal pages and theme selection. Linux desktop packaging was exercised with electron-builder 26.18.0; AppImage and Debian outputs were generated.
- Desktop production dependency audit reported zero vulnerabilities after using the native input modules directly, without the unused image-processing dependency chain. This is a point-in-time advisory check, not a security guarantee.
- Six source-archive extraction tests passed, including required files, wrapped/flat layouts, traversal/case collisions, links and destination protection.
- Three signing-helper tests passed using fixture provisioning plists: separate app/extension profiles, rejection of missing extension App Group entitlement and expired profiles. These do not verify a real Apple signature.
- Swift source syntax was parsed, and project/plist/entitlement/Android XML/JavaScript/shell/workflow syntax checked. Syntax parsing is **not Apple SDK type-checking**. The ReplayKit extension has not been compiled or run in this Linux environment.

The managed Chromium policy disables non-proxied UDP. Browser transport tests therefore used the supported TURN/TCP fallback without changing policy. Direct LAN/UDP, mobile network changes and a real public HTTPS/TURN deployment remain unverified here.

## Still required on real platforms

1. Run the updated GitHub macOS job: compile app + broadcast extension, run native recording and UI tests, then archive/export with both real Apple profiles and the shared group.
2. On physical iPhone and iPad, test broadcast startup, pause/resume, rotation, foreground/background, stop from both app and system indicator, local wipe acknowledgement, thermal load and broadcast-extension memory pressure. Verify the extension remains within iOS limits; no measured memory/latency claim is made.
3. On Android 10/13/14/16, test full-display capture consent, notification denial, rotation, lock, Accessibility enabled/disabled/reconnected, gestures and stop revocation. Test sharing and viewing together, including vendor battery restrictions.
4. Run macOS/Windows builds and actual capture/input with normal OS permissions. Verify macOS Accessibility/Screen Recording denial and recovery; Windows DPI/multiple monitors/UAC; Linux X11 multiple monitors and Wayland input disabled. The Linux headless runtime test does not validate real display capture or native input.
5. Test iOS MP4 and desktop WebM recording with real frames, recording revocation, low storage/limits, failed saves and exported files outside wipe.
6. Deploy a trusted HTTPS/TURN service and test two different networks, relay-only UDP/TCP/TLS, interruptions, invitation expiry and resource/abuse limits. No production service was deployed here.
7. Check VoiceOver/TalkBack, large text, light/dark contrast, reduced motion, keyboard navigation and profiling on target hardware. Complete desktop signing/notarization, app-store disclosures/review and legal review before a production distribution.

Screenshots show browser fixtures, not proof of native iOS or Android runtime behavior. Previous user CI successfully built the earlier app; the new bidirectional architecture and extension still need the updated native CI/device matrix. No guarantee of zero delay, uninterrupted connection or unrestricted iOS background/control is made.
