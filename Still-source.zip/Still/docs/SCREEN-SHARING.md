# Screen sharing and control · Still 2.0

1. Deploy the HTTPS connection service and configure TURN once; see [relay setup](../relay/README.md). The source includes no public endpoint.
2. On the host, choose **Share this device**, select quality and optional recording/control permissions, then approve the system screen-sharing prompt.
3. Share the invitation. On the viewer, paste it into **View a device** and connect. An invitation admits one viewer.
4. Control is available only when the host allowed it. Turn on Control on the viewer to send gestures. Stop sharing to end access.

Android and desktop can share and view simultaneously through separate sessions. iOS uses ReplayKit for sending, can view while the main app is foregrounded, and can control approved Android/desktop hosts. **Other devices cannot inject actions into an iPhone or iPad.** Never present Device Admin, MDM or Accessibility as a way around that restriction.

## Host permissions

- **Android:** the system MediaProjection consent prompt and a visible foreground service. For input, the owner reads the in-app disclosure, enables Still in Accessibility settings, then chooses Allow control for the current session. Still requests gesture execution without window-content retrieval. Stop revokes input; system Accessibility permission remains until disabled there. Whole-display capture is used so normalized remote gestures map to the shared display.
- **iOS/iPadOS:** app and broadcast extension signed with a common App Group. The user prepares a session and taps the system broadcast picker. Video sample buffers are transmitted; audio buffers are ignored. The system indicator is the immediate stop control. No input-injection or private API is used. The extension limits capture to a 960×540 / 15fps target and prefers H.264; real memory/thermal behavior needs device testing.
- **macOS:** screen-capture permission and, for optional input, Accessibility permission. Restart the session after granting permissions.
- **Windows:** normal desktop capture/input; no control of secure desktops, elevated apps or UAC prompts is promised.
- **Linux:** capture depends on the compositor/portal. Native input requires X11; Wayland input is disabled.

Desktop control is revoked on viewer departure or signaling loss. A new local share is needed to grant it again. Supported commands are bounded tap/click, drag/swipe, scroll and selected navigation keys and bounded text entry. Android accepts tap/swipe and Back/Home/Recents; desktop accepts pointer gestures and navigation keys. No remote shell, file transfer or clipboard synchronization is exposed.

## Background, recording and network behavior

Android capture can continue through its foreground service, and desktop capture while its window remains open behind other apps. iOS system broadcasting can continue outside the main app; the iOS viewer itself stops when the app backgrounds. OS lock, battery policy, revoked permissions and protected content can stop or blank capture. There is no always-on or zero-latency guarantee.

The host must allow built-in recording. iOS viewers save video-only MP4 in the app, with preview/export/delete and local wipe; the existing limit is thirty minutes or low storage. Desktop viewers save video-only WebM to a user-selected location after stopping; recording stops after twenty minutes or approximately 128 MiB. Desktop exports remain outside local wipe. Android viewing has no built-in recorder. External capture cannot be prevented by an app consent flag.

Both devices must reach the configured HTTPS service. WebRTC encrypts media and the remote-input data channel, connects directly when possible and uses TURN where needed. Signaling operators see negotiation metadata; TURN sees endpoints/timing/volume. No provider is silently selected. Test a real deployment on separate networks, including TURN/TCP/TLS, before distribution.

The legacy browser sender still supports receiver-created invitations. A new sender-created invitation can be opened with **View this screen** in a browser without downloading a desktop app. Browser viewing supports video and basic gestures when the host permits them; full native host features need the app.

[Validation record](VALIDATION.md) distinguishes automated fixture tests from outstanding real-device capture and input checks.
