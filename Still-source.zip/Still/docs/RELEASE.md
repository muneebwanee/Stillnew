# Release readiness · Still 2.0

The source and build workflows implement bidirectional screen transport, supported controls and a simplified interface. Automated Linux checks are listed in [VALIDATION](VALIDATION.md). A successful build is a development milestone, not production certification.

Before a public release, complete the real-device matrix in that record, including ReplayKit extension compilation/memory, Android MediaProjection/Accessibility lifecycle, desktop native capture/input, multiple monitors/DPI, permission denial/recovery, recording/storage and actual public TURN connectivity. Keep a visible Stop action and system sharing indicators. Do not describe iOS as remotely controllable or promise silent indefinite capture.

Configure a real HTTPS connection operator and publish its identity, privacy practices, retention and bandwidth costs. The source includes no hosted endpoint. Protect TURN from private-network relay abuse; apply infrastructure authentication, quotas and operational controls appropriate to a public service.

For Apple distribution, provision both app and `.broadcast` extension with the same App Group, export using the intended distribution method, validate the archive and complete App Store privacy/review requirements. For Android, choose a stable release-signing key and complete current screen capture/foreground service/Accessibility disclosure and store policies. Desktop packages need platform signing/notarization and installation/permission testing. The default CI desktop builds are unsigned; Android is debug-signed and iOS is unsigned unless explicitly configured.

Have the actual distributor review the bundled Terms, Privacy Policy, EULA, data-safety declarations and project-specific NCL for its real operator/jurisdiction. Retain all third-party notices and Electron/Chromium/node-module license files. Do not market Still as Google Cast, AirPlay, Miracast, MDM, a device-admin product, a protected-content bypass or a fully tested production remote-access suite before that evidence exists.
