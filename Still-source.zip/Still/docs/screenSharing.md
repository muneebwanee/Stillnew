# Whole-screen sharing

Version 2.0 · Effective November 11, 2026

## 1. Connect once

Use the HTTPS connection-service address supplied by your app distributor. Enter it in the sharing settings on devices that create invitations. The project includes a deployable service and TURN guide; no public service is preconfigured. You do not need an account.

## 2. Share this device

Choose Share this device on the screen you want to show. Android asks for whole-display capture permission; desktop asks you to choose a display. On iPhone/iPad, prepare sharing, tap the system broadcast button and choose Start Broadcast. Start sharing before sending the invitation. Keep the full invitation private.

## 3. View a device

On the viewing device, paste the host’s invitation and choose View a device or Connect. One viewer can join each invitation. Android and desktop can send and view at the same time. iOS can broadcast its screen while its foreground app views another device, but a video call loop can appear if both screens show each other. The iOS viewer stops when Still goes into the background; the system broadcast can continue.

## 4. Allow control only when needed

Control is off by default. Android hosts must first enable Still’s Accessibility service in system settings and then allow control for this session. Desktop hosts choose Allow control before selecting a display; macOS needs Accessibility permission, Linux input needs X11. On the viewer, enable Control, then tap/click or drag on the video. Android hosts support taps, swipes, Back, Home and recent apps. Desktop hosts support clicks, drags, scrolling and selected navigation keys. Desktop hosts also accept bounded printable text from supported controllers. Clipboard sync, file transfer, shells and iOS remote input are not provided. Stop sharing to revoke control.

## 5. Record with permission

The host must allow recording. iOS viewers can save video-only MP4 locally, preview, share or delete it in Recordings. iOS recordings stop at thirty minutes or low storage. Desktop viewers can record video-only WebM and choose a save destination; recording stops at twenty minutes or approximately 128 MiB. Android viewing does not include a recording feature. An invitation recipient can still use external capture tools; the app setting cannot prevent that.

## 6. Background and stop

Android sharing uses an ongoing system foreground service with a Stop action. Desktop sharing continues while its app window remains open, including behind other apps. iOS uses a visible ReplayKit broadcast indicator and can share outside Still; end it using that indicator or End sharing in the app. Receiving on iPhone/iPad needs Still in the foreground. OS locks, protected screens, battery policy, lost permissions and network interruptions can pause or stop capture. There is no silent or guaranteed always-on mode.

## 7. Nearby and far away

Both devices need access to the configured connection service. WebRTC can connect directly or through encrypted TURN transport. Distance, network congestion and firewalls affect delay and picture quality. Use Lighter quality on a slow connection. Clients try a bounded reconnect; start a fresh invitation if recovery fails. Sessions expire after two hours. Desktop control consent ends after a viewer leaves or signaling reconnects; start a new local share to grant it again.

## 8. Before sharing

Close private content and consider hiding notifications. Anyone holding the invitation may see the selected screen and perform any actions you allowed. Only invite people you trust and supervise control. Microphone, system audio, camera, protected-content bypass and unrestricted iOS control are unavailable. Read Privacy & terms for the complete policy and permission details.
