#!/usr/bin/env python3
"""Validate both Apple profiles and create per-target signing settings."""
import datetime,json,os,pathlib,plistlib,re,shutil,subprocess,uuid
root=pathlib.Path(os.environ['RUNNER_TEMP'])
team=os.environ['APPLE_TEAM_ID'];bundle=os.environ.get('BUNDLE_ID','com.muneebwanee.still');group=os.environ.get('APP_GROUP','group.'+bundle)
method=os.environ.get('EXPORT_METHOD','release-testing')
if not re.fullmatch(r'[A-Z0-9]{10}',team):raise SystemExit('Set APPLE_TEAM_ID to your Apple team ID.')
if not all(re.fullmatch(r'[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+',v) for v in (bundle,group)):raise SystemExit('Set valid IOS_BUNDLE_ID and IOS_APP_GROUP values.')
if method not in ('release-testing','app-store-connect'):raise SystemExit('Choose a supported export method.')
folder=pathlib.Path(os.environ.get('STILL_PROFILES_DIRECTORY', str(pathlib.Path.home()/'Library/MobileDevice/Provisioning Profiles')));folder.mkdir(parents=True,exist_ok=True)
profiles={};spec='include:\n  - project.yml\nsettings:\n  base:\n    STILL_BUNDLE_ID: '+json.dumps(bundle)+'\n    STILL_APP_GROUP: '+json.dumps(group)+'\ntargets:\n'
for target,suffix,name in [('Still','','still-profile'),('StillBroadcastUpload','.broadcast','still-broadcast-profile')]:
    source=root/(name+'.mobileprovision');raw=subprocess.check_output(['security','cms','-D','-i',str(source)]);profile=plistlib.loads(raw);entitlements=profile['Entitlements'];expected=team+'.'+bundle+suffix
    if entitlements.get('application-identifier')!=expected:raise SystemExit('Provisioning profile must match '+expected)
    if group not in entitlements.get('com.apple.security.application-groups',[]):raise SystemExit('Enable App Group '+group+' in BOTH app and broadcast-extension profiles.')
    if profile['ExpirationDate'].replace(tzinfo=datetime.timezone.utc)<=datetime.datetime.now(datetime.timezone.utc):raise SystemExit('The '+target+' profile has expired.')
    identifier=str(uuid.UUID(profile['UUID'])).upper();shutil.copy(source,folder/(identifier+'.mobileprovision'));profiles[bundle+suffix]=identifier
    with open(os.environ['GITHUB_ENV'],'a') as output:output.write(('PROFILE_UUID' if not suffix else 'BROADCAST_PROFILE_UUID')+'='+identifier+'\n')
    settings={'PRODUCT_BUNDLE_IDENTIFIER':bundle+suffix,'DEVELOPMENT_TEAM':team,'CODE_SIGN_STYLE':'Manual','CODE_SIGN_IDENTITY':'Apple Distribution','PROVISIONING_PROFILE_SPECIFIER':identifier}
    spec+='  '+target+':\n    settings:\n      base:\n'+''.join('        '+k+': '+json.dumps(v)+'\n' for k,v in settings.items())
pathlib.Path('project.signed.yml').write_text(spec)
options={'method':method,'teamID':team,'signingStyle':'manual','signingCertificate':'Apple Distribution','provisioningProfiles':profiles}
(root/'Still-ExportOptions.plist').write_bytes(plistlib.dumps(options))
