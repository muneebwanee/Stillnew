#!/bin/bash
set -euo pipefail
python3 - <<'PY'
import base64,os,pathlib
root=pathlib.Path(os.environ['RUNNER_TEMP'])
for variable,name in [('CERTIFICATE','still-certificate.p12'),('PROFILE','still-profile.mobileprovision'),('BROADCAST_PROFILE','still-broadcast-profile.mobileprovision')]:
    value=os.environ.get(variable,'')
    if not value:raise SystemExit('Missing signing secret: '+variable+' (broadcasting requires a separate extension profile).')
    (root/name).write_bytes(base64.b64decode(value,validate=True))
PY
KEYCHAIN_PASSWORD=$(openssl rand -hex 24)
echo "::add-mask::$KEYCHAIN_PASSWORD"
security create-keychain -p "$KEYCHAIN_PASSWORD" "$RUNNER_TEMP/still.keychain-db"
security set-keychain-settings -lut 21600 "$RUNNER_TEMP/still.keychain-db"
security unlock-keychain -p "$KEYCHAIN_PASSWORD" "$RUNNER_TEMP/still.keychain-db"
security import "$RUNNER_TEMP/still-certificate.p12" -P "$CERTIFICATE_PASSWORD" -A -t cert -f pkcs12 -k "$RUNNER_TEMP/still.keychain-db"
security set-key-partition-list -S apple-tool:,apple:,codesign: -k "$KEYCHAIN_PASSWORD" "$RUNNER_TEMP/still.keychain-db"
security list-keychains -d user -s "$RUNNER_TEMP/still.keychain-db" login.keychain-db
python3 scripts/prepare-signing.py
