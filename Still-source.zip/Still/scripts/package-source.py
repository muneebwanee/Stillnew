#!/usr/bin/env python3
"""Create the uploadable source archive, excluding builds and machine-local configuration."""
from pathlib import Path
import os,zipfile
ROOT=Path(__file__).resolve().parents[1]
FILES=['project.yml','README.md','LICENSE','GITHUB-RELEASE-SETUP.md','build-release.yml','.gitignore']
DIRECTORIES=['Still','Shared','StillBroadcastUpload','StillTests','StillUITests','Packages','android-sender','desktop','relay','docs','scripts','tests','.github']
EXCLUDED={'.git','node_modules','build','dist','.gradle','.build','__pycache__','DerivedData','playwright-report','test-results'}
paths=[ROOT/name for name in FILES]
for name in DIRECTORIES:
    for folder,dirs,files in os.walk(ROOT/name):
        dirs[:]=sorted(d for d in dirs if d not in EXCLUDED)
        for file in sorted(files):
            path=Path(folder)/file
            if path.is_symlink():raise SystemExit('Source archives must not contain links: '+str(path))
            if file in ('local.properties','config.local.env','.DS_Store') or file.startswith('.env') or path.suffix in ('.p12','.mobileprovision','.ipa','.apk','.AppImage','.deb','.dmg','.exe','.xcuserstate','.pyc'):continue
            paths.append(path)
archive=ROOT/'Still-source.zip';temporary=ROOT/'Still-source.tmp.zip'
with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for path in sorted(paths):output.write(path,'Still/'+path.relative_to(ROOT).as_posix())
temporary.replace(archive)
print('Created',archive.name,'with',len(paths),'source files; size',archive.stat().st_size,'bytes.')
