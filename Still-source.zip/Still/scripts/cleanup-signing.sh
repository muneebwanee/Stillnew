#!/bin/bash
set -euo pipefail
security delete-keychain "$RUNNER_TEMP/still.keychain-db" || true
rm -f "$RUNNER_TEMP/still-certificate.p12" "$RUNNER_TEMP/still-profile.mobileprovision" "$RUNNER_TEMP/still-broadcast-profile.mobileprovision" "$RUNNER_TEMP/Still-ExportOptions.plist"
if [ -n "${PROFILE_UUID:-}" ]; then rm -f "$HOME/Library/MobileDevice/Provisioning Profiles/$PROFILE_UUID.mobileprovision"; fi
if [ -n "${BROADCAST_PROFILE_UUID:-}" ]; then rm -f "$HOME/Library/MobileDevice/Provisioning Profiles/$BROADCAST_PROFILE_UUID.mobileprovision"; fi
