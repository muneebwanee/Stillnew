import ReplayKit
import ImageIO
@preconcurrency import WebRTC

final class SampleHandler: RPBroadcastSampleHandler {
    private var engine: BroadcastEngine?
    override func broadcastStarted(withSetupInfo setupInfo: [String : NSObject]?) {
        guard let config = BroadcastConfiguration.load() else { finishBroadcastWithError(NSError(domain: "Still", code: 1, userInfo: [NSLocalizedDescriptionKey:"Prepare screen sharing in Still first."])); return }
        let engine = BroadcastEngine(configuration: config)
        engine.ended = { [weak self] message in self?.finishBroadcastWithError(NSError(domain: "Still", code: 2, userInfo: [NSLocalizedDescriptionKey:message])) }
        self.engine = engine; engine.start()
    }
    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer, with sampleBufferType: RPSampleBufferType) { if sampleBufferType == .video { engine?.capture(sampleBuffer) } }
    override func broadcastPaused() { engine?.setPaused(true) }
    override func broadcastResumed() { engine?.setPaused(false) }
    override func broadcastFinished() { engine?.stop(); engine = nil }
}

private final class BroadcastEngine: NSObject, RTCPeerConnectionDelegate {
    let config: BroadcastConfiguration
    var ended: ((String) -> Void)?
    private let queue = DispatchQueue(label: "still.broadcast.signal")
    private let frameLock = NSLock()
    private var streaming = false, paused = false
    private var lastFrame = 0.0
    private let factory: RTCPeerConnectionFactory
    private let source: RTCVideoSource
    private let capturer: RTCVideoCapturer
    private let video: RTCVideoTrack
    private var socket: URLSessionWebSocketTask?
    private var peer: RTCPeerConnection?
    private var ice: [RTCIceServer] = []
    private var pending: [RTCIceCandidate] = []
    private var timer: DispatchSourceTimer?
    private var stopped = false, attempts = 0
    init(configuration: BroadcastConfiguration) {
        config = configuration; RTCInitializeSSL()
        let encoders = RTCDefaultVideoEncoderFactory()
        if let h264 = RTCDefaultVideoEncoderFactory.supportedCodecs().first(where: { $0.name == "H264" }) { encoders.preferredCodec = h264 }
        let rtcFactory = RTCPeerConnectionFactory(encoderFactory: encoders, decoderFactory: RTCDefaultVideoDecoderFactory())
        let rtcSource = rtcFactory.videoSource(); rtcSource.adaptOutputFormat(toWidth: 960, height: 540, fps: 15)
        factory = rtcFactory; source = rtcSource
        capturer = RTCVideoCapturer(delegate: rtcSource); video = rtcFactory.videoTrack(with: rtcSource, trackId: "screen")
        super.init()
    }
    func start() { queue.async {
        self.connect()
        let timer = DispatchSource.makeTimerSource(queue: self.queue)
        timer.schedule(deadline: .now()+1, repeating: 1)
        timer.setEventHandler { [weak self] in
            guard let self, !self.stopped else { return }
            if Date().timeIntervalSince(self.config.created) >= 7200 || BroadcastConfiguration.store?.string(forKey: BroadcastConfiguration.stopKey) == self.config.room { self.finish("Screen sharing ended.") }
        }; self.timer = timer; timer.resume()
    } }
    private func connect() {
        guard !stopped else { return }
        var parts = URLComponents(url: config.origin, resolvingAgainstBaseURL: false)!
        parts.scheme = "wss"; parts.path = "/signal"
        let socket = URLSession.shared.webSocketTask(with: parts.url!); self.socket = socket; socket.resume()
        send(["type":"create","role":"sender","room":config.room,"owner":config.owner,"invite":config.invite,"allowRecording":config.allowRecording,"allowControl":false,"controlKind":"none"])
        receive(socket)
    }
    private func receive(_ socket: URLSessionWebSocketTask) {
        socket.receive { [weak self] result in
            guard let self else { return }; self.queue.async {
                guard !self.stopped, self.socket === socket else { return }
                switch result {
                case .success(let value):
                    let data: Data
                    switch value { case .data(let bytes): data = bytes; case .string(let text): data = Data(text.utf8); @unknown default: return }
                    if let message = try? JSONSerialization.jsonObject(with: data) as? [String: Any] { self.handle(message) }
                    self.receive(socket)
                case .failure: self.reconnect()
                }
            }
        }
    }
    private func handle(_ message: [String: Any]) {
        switch message["type"] as? String {
        case "ready":
            ice = (message["iceServers"] as? [[String: Any]] ?? []).compactMap { item in guard let urls = item["urls"] as? [String] else { return nil }; return RTCIceServer(urlStrings: urls, username: item["username"] as? String, credential: item["credential"] as? String) }
            BroadcastConfiguration.store?.set("Waiting for another device", forKey: BroadcastConfiguration.statusKey)
        case "peer-joined", "receiver-back": offer()
        case "answer":
            guard let peer, let sdp = message["sdp"] as? String else { return }
            peer.setRemoteDescription(RTCSessionDescription(type: .answer, sdp: sdp)) { [weak self] error in
                guard let self else { return }; self.queue.async { guard self.peer === peer else { return }; if error != nil { self.reconnect(); return }; for candidate in self.pending { peer.add(candidate) { _ in } }; self.pending.removeAll() }
            }
        case "candidate":
            guard let text = message["candidate"] as? String, let index = message["sdpMLineIndex"] as? Int32 else { return }
            let candidate = RTCIceCandidate(sdp: text, sdpMLineIndex: index, sdpMid: message["sdpMid"] as? String)
            if let peer, peer.remoteDescription != nil { peer.add(candidate) { _ in } } else if pending.count < 256 { pending.append(candidate) }
        case "peer-left", "receiver-away": closePeer(); BroadcastConfiguration.store?.set("Waiting for another device", forKey: BroadcastConfiguration.statusKey)
        case "recording": BroadcastConfiguration.store?.set(message["active"] as? Bool == true ? "The other device is recording" : "Sharing your screen", forKey: BroadcastConfiguration.statusKey)
        case "ended": finish("The session ended.")
        case "error": finish(message["message"] as? String ?? "Screen sharing could not connect.")
        default: break
        }
    }
    private func offer() {
        closePeer(); let configuration = RTCConfiguration(); configuration.sdpSemantics = .unifiedPlan; configuration.iceServers = ice
        guard let peer = factory.peerConnection(with: configuration, constraints: RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil), delegate: self) else { return }
        self.peer = peer; _ = peer.add(video, streamIds: ["still-screen"])
        peer.offer(for: RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil)) { [weak self] description, error in
            guard let self else { return }; self.queue.async {
                guard !self.stopped, self.peer === peer, error == nil, let description else { return }
                peer.setLocalDescription(description) { [weak self] error in guard error == nil, let self else { return }; self.queue.async { if self.peer === peer { self.send(["type":"offer","sdp":description.sdp]) } } }
            }
        }
    }
    private func send(_ message: [String: Any]) { guard let socket, let data = try? JSONSerialization.data(withJSONObject: message) else { return }; socket.send(.data(data)) { _ in } }
    private func closePeer() { frameLock.lock(); streaming = false; frameLock.unlock(); peer?.delegate = nil; peer?.close(); peer = nil; pending.removeAll() }
    private func reconnect() {
        guard !stopped else { return }; closePeer(); socket?.cancel(with: .goingAway, reason: nil); socket = nil
        guard attempts < 6 else { finish("Connection lost. Start a new broadcast."); return }
        let delay = min(10, pow(2, Double(attempts))); attempts += 1
        BroadcastConfiguration.store?.set("Reconnecting…", forKey: BroadcastConfiguration.statusKey)
        queue.asyncAfter(deadline: .now()+delay) { [weak self] in self?.connect() }
    }
    func capture(_ sample: CMSampleBuffer) {
        guard frameLock.try() else { return }; defer { frameLock.unlock() }
        let now = ProcessInfo.processInfo.systemUptime
        guard streaming, !paused, now-lastFrame >= 1.0/15, let pixel = CMSampleBufferGetImageBuffer(sample) else { return }
        lastFrame = now
        let seconds = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample))
        guard seconds.isFinite else { return }
        let orientation = (CMGetAttachment(sample, key: RPVideoSampleOrientationKey as CFString, attachmentModeOut: nil) as? NSNumber)?.uint32Value ?? 1
        let rotation: RTCVideoRotation
        switch CGImagePropertyOrientation(rawValue: orientation) { case .right: rotation = ._90; case .down: rotation = ._180; case .left: rotation = ._270; default: rotation = ._0 }
        let frame = RTCVideoFrame(buffer: RTCCVPixelBuffer(pixelBuffer: pixel), rotation: rotation, timeStampNs: Int64(seconds*1_000_000_000))
        source.capturer(capturer, didCapture: frame)
    }
    func setPaused(_ value: Bool) { frameLock.lock(); paused = value; frameLock.unlock() }
    func stop() { queue.async { self.end() } }
    private func end() { guard !stopped else { return }; stopped = true; timer?.cancel(); timer = nil; closePeer(); if let socket, let data = try? JSONSerialization.data(withJSONObject: ["type":"end"]) { socket.send(.data(data)) { _ in socket.cancel(with: .normalClosure, reason: nil) } }; socket = nil; BroadcastConfiguration.store?.set("Sharing stopped", forKey: BroadcastConfiguration.statusKey) }
    private func finish(_ text: String) { end(); ended?(text) }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange stateChanged: RTCSignalingState) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didAdd stream: RTCMediaStream) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove stream: RTCMediaStream) {}
    func peerConnectionShouldNegotiate(_ peerConnection: RTCPeerConnection) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceConnectionState) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceGatheringState) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didGenerate candidate: RTCIceCandidate) { queue.async { guard self.peer === peerConnection else { return }; self.send(["type":"candidate","candidate":candidate.sdp,"sdpMid":candidate.sdpMid as Any? ?? NSNull(),"sdpMLineIndex":candidate.sdpMLineIndex]) } }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove candidates: [RTCIceCandidate]) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didOpen dataChannel: RTCDataChannel) { dataChannel.close() }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCPeerConnectionState) { queue.async { guard self.peer === peerConnection else { return }; if newState == .connected { self.frameLock.lock(); self.streaming = true; self.frameLock.unlock(); self.attempts = 0; BroadcastConfiguration.store?.set("Sharing your screen", forKey: BroadcastConfiguration.statusKey) } else if newState == .failed { self.reconnect() } } }
}
