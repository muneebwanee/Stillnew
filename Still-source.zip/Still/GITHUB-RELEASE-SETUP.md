# Upload ZIP → build → release

Download **Still-source.zip** and **build-release.yml**. Replace both older files in your repository.

1. Upload `Still-source.zip` to the repository root. Keep that exact filename; no extraction is needed.
2. Put the downloaded workflow at **`.github/workflows/build-release.yml`**, replacing the old workflow. A YAML file at the repository root does not run.
3. Commit both on `main` or `master`. Open **Actions → Build ZIP and release**. The run validates the archive and protocol, tests/builds iOS, builds/lints Android, packages Windows/macOS/Linux desktop apps, then publishes a GitHub prerelease.
4. Download binaries from **Releases → Assets**. Use **Run workflow** to disable optional Android/desktop builds or select Apple signing. Re-running an old failed run uses its old source; start a run from the new commit.

## Default artifacts

- `Still-2.0.0-unsigned.ipa`: must be signed before installation. Broadcasting additionally requires a properly provisioned App Group and extension.
- `Still-Android-2.0.0-debug.apk`: debug-signed Android test distribution. A regenerated CI debug key may require uninstalling an older build before installing.
- Desktop `.exe`, `.dmg`, `.AppImage`, `.deb`: unsigned development distributions. macOS packages are not notarized; Windows packages have no trusted publisher signature. OS permissions and normal installation policies still apply.
- Source ZIP and SHA-256 checksums.

The workflow does not deploy a connection service, provide an Apple account, notarize desktop apps or submit to app stores. Before actual screen sharing, deploy the included HTTPS service and TURN once; see [relay setup](relay/README.md). Supply that address to users. No hosted free server is preconfigured. If you already deployed an older Still relay, deploy the updated `relay/` code too: the new apps require sender-owned rooms and capability messages.

## Signed iOS broadcasting

Apple ReplayKit sending now uses **two signed targets**:

| Target | Default bundle ID |
| --- | --- |
| Main app | `com.muneebwanee.still` |
| Broadcast extension | `com.muneebwanee.still.broadcast` |

Register both identifiers in your Apple Developer account. Register App Group **`group.com.muneebwanee.still`**, enable it on both identifiers, and regenerate both provisioning profiles with that entitlement. Both profiles must use the same team, certificate, group and distribution method. For ad hoc installation, register the intended device UDIDs in both profiles. Personal-team capabilities may not include App Groups; check your account.

Add these **repository Actions secrets** in Settings → Secrets and variables → Actions:

| Secret | Value |
| --- | --- |
| `APPLE_TEAM_ID` | Apple’s 10-character team ID |
| `IOS_CERTIFICATE_BASE64` | Base64-encoded Apple Distribution `.p12` with private key |
| `IOS_CERTIFICATE_PASSWORD` | Password for that `.p12` |
| `IOS_PROFILE_BASE64` | Main app provisioning profile, base64-encoded |
| **`IOS_BROADCAST_PROFILE_BASE64`** | **Broadcast extension provisioning profile, base64-encoded** |

If using your own identifiers, set repository variables **`IOS_BUNDLE_ID`** and **`IOS_APP_GROUP`** together. The extension ID is the main ID plus `.broadcast`. The group must exactly match the entitlement in both profiles.

Run Actions → Build ZIP and release → Run workflow, enable signing, and choose `release-testing` for ad hoc or `app-store-connect` for a TestFlight/App Store upload artifact. The latter does not install directly and this workflow does not submit it to Apple. Per-target signing prevents the extension from accidentally receiving the main app’s bundle ID or profile.

The signing helper checks profile expiry, exact identifiers and the group entitlement on both targets before archiving. Keep certificate/private-key/profile files in encrypted Secrets, never in the source ZIP.

## First-use flow

On the host, choose **Share this device**, configure the connection-service address once, select permissions and approve capture. On iOS, tap the broadcast picker and start the system broadcast. Send the invitation to the other device. On the viewer, paste it into **View a device** and connect.

Android control needs Still enabled in Accessibility settings plus **Allow control for this session**. macOS control needs Accessibility permission. Linux control needs X11. iPhone/iPad hosts remain view-only; they can act as viewers/controllers for other supported hosts. iOS viewing needs the app foregrounded; system broadcasting can continue outside the app.

## Troubleshooting

- Missing archive: preserve `Still-source.zip` at the root.
- Workflow missing: check `.github/workflows/build-release.yml` and enable Actions. Use Run workflow for a differently named default branch, or adjust the branch list.
- Signing rejects the group: regenerate **both** profiles after enabling the App Group. The old app-only signing secrets are insufficient for the new broadcast extension.
- No broadcast option or broadcast stops: confirm the installed `.appex`, its signing/profile and App Group entitlement; test on a physical iPhone/iPad. Simulator broadcasting is unavailable.
- Connections fail across networks: verify deployed HTTPS/WSS and TURN UDP/TCP/TLS/firewall configuration. Building binaries alone does not create the service.
- Android control unavailable: enable the service in Accessibility, then start a new share with Allow control. Do not expect remote actions on protected screens.
- Release skipped: inspect the first failed job; required validation remains enabled. Desktop jobs can be explicitly disabled in Run workflow if only mobile artifacts are needed.
- Release permission error: repository policy must allow the job’s `contents: write` token permission.

[Validation record](docs/VALIDATION.md) states what passed locally and what still requires native hardware, Apple toolchains or the next GitHub run.
