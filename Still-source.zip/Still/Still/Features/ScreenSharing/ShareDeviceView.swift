import SwiftUI
import ReplayKit

struct ShareDeviceView: View {
    @EnvironmentObject private var broadcast: BroadcastSession
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    Image(systemName: "rectangle.on.rectangle").font(.system(size: 40, weight: .ultraLight))
                    Text("Share this device").font(.largeTitle.weight(.medium)).tracking(-1)
                    Text("Let another device see your screen. You choose when to start and stop.").foregroundStyle(.secondary)
                    if let invitation = broadcast.invitation {
                        HStack(spacing: 18) { SystemBroadcastPicker().frame(width: 64, height: 64); Text("Tap the broadcast button and choose Start Broadcast.").font(.callout) }
                        ShareLink(item: invitation) { Label("Share invitation", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity) }.buttonStyle(StillPrimaryButtonStyle())
                        Text(broadcast.status).font(.footnote).foregroundStyle(.secondary)
                        Button("End sharing", role: .destructive) { broadcast.stop() }
                    } else {
                        Toggle("Allow recording", isOn: $broadcast.allowRecording)
                        Button("Prepare screen sharing") { broadcast.prepare() }.buttonStyle(StillPrimaryButtonStyle())
                    }
                    if let error = broadcast.error { Text(error).font(.footnote).foregroundStyle(.red) }
                    Text("iPhone and iPad sharing is view-only. Anything visible on screen may be shared, including notifications. Stop from the system broadcast indicator at any time.").font(.footnote).foregroundStyle(.secondary)
                    NavigationLink("Connection settings") { ScreenConnectionSettingsView() }
                }.padding(24).frame(maxWidth: 560).frame(maxWidth: .infinity)
            }.navigationTitle("Share").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }.task { while !Task.isCancelled { broadcast.refresh(); do { try await Task.sleep(for: .seconds(1)) } catch { return } } }
    }
}
private struct SystemBroadcastPicker: UIViewRepresentable {
    func makeUIView(context: Context) -> RPSystemBroadcastPickerView {
        let view = RPSystemBroadcastPickerView(frame: CGRect(x: 0, y: 0, width: 64, height: 64))
        view.preferredExtension = (Bundle.main.bundleIdentifier ?? "com.muneebwanee.still") + ".broadcast"
        view.showsMicrophoneButton = false
        view.accessibilityLabel = "Start system screen broadcast"
        return view
    }
    func updateUIView(_ uiView: RPSystemBroadcastPickerView, context: Context) {}
}
