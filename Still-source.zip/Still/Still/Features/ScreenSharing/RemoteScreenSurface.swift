import SwiftUI
@preconcurrency import WebRTC

struct RemoteScreenSurface: UIViewRepresentable {
    let track: RTCVideoTrack
    let controlling: Bool
    let send: ([String: Any]) -> Void
    func makeUIView(context: Context) -> Surface { Surface() }
    func updateUIView(_ view: Surface, context: Context) { view.install(track); view.controlling = controlling; view.send = send }
    static func dismantleUIView(_ view: Surface, coordinator: ()) { view.detach() }
    @MainActor final class Surface: UIView, RTCVideoViewDelegate {
        private let video = RTCMTLVideoView(frame: .zero)
        private var track: RTCVideoTrack?
        private var sourceSize = CGSize.zero
        private var beginning: CGPoint?
        private var beganAt = 0.0
        var send: (([String: Any]) -> Void)?
        var controlling = false { didSet { gestureRecognizers?.forEach { $0.isEnabled = controlling } } }
        override init(frame: CGRect) {
            super.init(frame: frame); backgroundColor = .black; video.videoContentMode = .scaleAspectFit; video.delegate = self; addSubview(video)
            let tap = UITapGestureRecognizer(target: self, action: #selector(tapped(_:)))
            let pan = UIPanGestureRecognizer(target: self, action: #selector(panned(_:)))
            tap.require(toFail: pan); addGestureRecognizer(tap); addGestureRecognizer(pan)
        }
        required init?(coder: NSCoder) { fatalError("Use init(frame:)") }
        override func layoutSubviews() { super.layoutSubviews(); video.frame = bounds }
        func install(_ track: RTCVideoTrack) { if self.track !== track { detach(); self.track = track; track.add(video) } }
        func detach() { track?.remove(video); track = nil }
        nonisolated func videoView(_ videoView: any RTCVideoRenderer, didChangeVideoSize size: CGSize) { Task { @MainActor [weak self] in self?.sourceSize = size } }
        private func point(_ point: CGPoint) -> CGPoint? {
            guard controlling, sourceSize.width > 0, sourceSize.height > 0 else { return nil }
            let scale = min(bounds.width/sourceSize.width, bounds.height/sourceSize.height)
            let rect = CGRect(x: (bounds.width-sourceSize.width*scale)/2, y: (bounds.height-sourceSize.height*scale)/2, width: sourceSize.width*scale, height: sourceSize.height*scale)
            guard rect.contains(point) else { return nil }
            return CGPoint(x: (point.x-rect.minX)/rect.width, y: (point.y-rect.minY)/rect.height)
        }
        @objc private func tapped(_ gesture: UITapGestureRecognizer) {
            guard let p = point(gesture.location(in: self)) else { return }
            send?(["type":"input","kind":"tap","x":p.x,"y":p.y])
        }
        @objc private func panned(_ gesture: UIPanGestureRecognizer) {
            if gesture.state == .began { beginning = point(gesture.location(in: self)); beganAt = ProcessInfo.processInfo.systemUptime }
            if gesture.state == .ended, let start = beginning, let end = point(gesture.location(in: self)) {
                send?(["type":"input","kind":"swipe","x":start.x,"y":start.y,"x2":end.x,"y2":end.y,"duration":max(100,min(1000,(ProcessInfo.processInfo.systemUptime-beganAt)*1000))]); beginning = nil
            }
            if gesture.state == .cancelled { beginning = nil }
        }
    }
}
