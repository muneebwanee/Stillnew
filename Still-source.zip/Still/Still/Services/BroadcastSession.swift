import SwiftUI
import ReplayKit

@MainActor final class BroadcastSession: ObservableObject {
    @Published private(set) var invitation: URL?
    @Published private(set) var status = "Ready"
    @Published var error: String?
    @Published var allowRecording = false
    private var room: String?
    init() { restore() }
    private func restore() { if let config = BroadcastConfiguration.load(), BroadcastConfiguration.store?.string(forKey: BroadcastConfiguration.stopKey) != config.room { room = config.room; invitation = config.invitation; allowRecording = config.allowRecording; refresh() } }
    func prepare() {
        if invitation != nil { refresh(); return }
        #if targetEnvironment(simulator)
        error = "Screen broadcasting needs a physical iPhone or iPad."; return
        #else
        guard FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: BroadcastConfiguration.group) != nil else { error = "This build needs its App Group enabled in Apple signing before broadcasting can start."; return }
        guard var parts = URLComponents(string: UserDefaults.standard.string(forKey: "sharingServer") ?? ""), parts.scheme == "https", parts.host != nil, parts.user == nil, parts.password == nil, parts.query == nil, parts.fragment == nil, parts.path.isEmpty || parts.path == "/" else { error = "Add your connection service in Settings → Screen sharing."; return }
        parts.path = ""; guard let origin = parts.url else { return }
        let token = { UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased() }
        let config = BroadcastConfiguration(origin: origin, room: token(), owner: token(), invite: token(), allowRecording: allowRecording, created: Date())
        do {
            let data = try JSONEncoder().encode(config)
            BroadcastConfiguration.store?.set(data, forKey: BroadcastConfiguration.configurationKey)
            BroadcastConfiguration.store?.removeObject(forKey: BroadcastConfiguration.stopKey)
            BroadcastConfiguration.store?.set("Ready to start", forKey: BroadcastConfiguration.statusKey)
            room = config.room; invitation = config.invitation; status = "Start the system broadcast, then share your invitation."; error = nil
        } catch { self.error = "The broadcast could not be prepared." }
        #endif
    }
    func refresh() { if let value = BroadcastConfiguration.store?.string(forKey: BroadcastConfiguration.statusKey) { status = value; if value == "Sharing stopped" { invitation = nil; room = nil; BroadcastConfiguration.store?.removeObject(forKey: BroadcastConfiguration.configurationKey) } } }
    func stop() { if let room { BroadcastConfiguration.store?.set(room, forKey: BroadcastConfiguration.stopKey) }; invitation = nil; status = "Stopping…" }
    func wipe() async -> Bool {
        refresh()
        let previous = BroadcastConfiguration.store?.string(forKey: BroadcastConfiguration.statusKey)
        let needsAcknowledgement = room != nil && previous != nil && previous != "Ready to start" && previous != "Sharing stopped"
        stop()
        var stopped = !needsAcknowledgement
        if needsAcknowledgement {
            for _ in 0..<30 {
                if BroadcastConfiguration.store?.string(forKey: BroadcastConfiguration.statusKey) == "Sharing stopped" { stopped = true; break }
                try? await Task.sleep(for: .milliseconds(100))
            }
        }
        BroadcastConfiguration.store?.removeObject(forKey: BroadcastConfiguration.configurationKey)
        BroadcastConfiguration.store?.removeObject(forKey: BroadcastConfiguration.statusKey)
        room = nil; error = nil; status = "Ready"
        return stopped
    }
}
