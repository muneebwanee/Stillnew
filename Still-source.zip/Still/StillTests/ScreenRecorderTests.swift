import XCTest
import AVFoundation
import WebRTC
@testable import Still

final class ScreenRecorderTests: XCTestCase {
    func testRotatedFramesProduceVideoOnlyMP4() async throws {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mp4")
        defer { try? FileManager.default.removeItem(at: file) }
        let recorder = ScreenRecorder(); recorder.start(at: file)
        var pixel: CVPixelBuffer?
        XCTAssertEqual(CVPixelBufferCreate(nil, 320, 180, kCVPixelFormatType_32BGRA, [kCVPixelBufferIOSurfacePropertiesKey as String: [:]] as CFDictionary, &pixel), kCVReturnSuccess)
        let buffer = try XCTUnwrap(pixel)
        CVPixelBufferLockBaseAddress(buffer, [])
        if let address = CVPixelBufferGetBaseAddress(buffer) { memset(address, 127, CVPixelBufferGetDataSize(buffer)) }
        CVPixelBufferUnlockBaseAddress(buffer, [])
        for index in 0..<8 {
            recorder.renderFrame(RTCVideoFrame(buffer: RTCCVPixelBuffer(pixelBuffer: buffer), rotation: ._90, timeStampNs: Int64(index) * 120_000_000))
            try await Task.sleep(for: .milliseconds(50))
        }
        let result: Result<URL, Error> = await withCheckedContinuation { continuation in recorder.finish { continuation.resume(returning: $0) } }
        let recorded = try result.get()
        let asset = AVURLAsset(url: recorded)
        let video = try await asset.loadTracks(withMediaType: .video)
        XCTAssertEqual(video.count, 1)
        let audio = try await asset.loadTracks(withMediaType: .audio)
        XCTAssertTrue(audio.isEmpty)
        let track = try XCTUnwrap(video.first)
        let size = try await track.load(.naturalSize)
        XCTAssertEqual(size, CGSize(width: 180, height: 320))
        let duration = try await asset.load(.duration)
        XCTAssertGreaterThan(duration.seconds, 0)
    }
    func testNoFrameSessionFailsWithoutLeavingARecording() async {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mp4")
        let recorder = ScreenRecorder(); recorder.start(at: file)
        let result: Result<URL, Error> = await withCheckedContinuation { continuation in recorder.finish { continuation.resume(returning: $0) } }
        if case .success = result { XCTFail("An empty capture must not be reported as a saved recording") }
        XCTAssertFalse(FileManager.default.fileExists(atPath: file.path))
    }
}
