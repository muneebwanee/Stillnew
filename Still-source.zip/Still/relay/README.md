# Still screen connection service

A small, self-hosted, in-memory signaling service for the WebRTC screen-sharing mode. It does **not** host the local YouTube/link receiver and does not turn the app into Google Cast. It adds no analytics, database or access-log feature. Hosting, proxies, STUN and TURN providers may keep independent operational records.

## Development

Node 22+:

```sh
npm ci
npm test
npm audit --omit=dev
```

`server.mjs` requires `PUBLIC_ORIGIN` to be an exact HTTPS origin without a path/trailing slash. HTTP loopback is accepted only for local testing. The service listens on loopback:8080 by default; run behind a TLS reverse proxy. `BIND_ADDRESS=0.0.0.0` is appropriate inside the included container, which is exposed only to its reverse proxy.

For a local protocol-only test:

```sh
PUBLIC_ORIGIN=http://127.0.0.1:8080 node server.mjs
```

A local loopback URL is not a usable cross-device iOS deployment. iOS requires a trusted HTTPS endpoint, and desktop screen capture requires a secure browser context. Do not disable TLS verification or globally weaken ATS.

## Deployment template

1. Point a real domain at your server. Configure its firewall for HTTPS and for the independently deployed TURN service.
2. Copy `config.example.env` to `config.local.env`. Use your exact public HTTPS origin, your STUN/TURN URLs and a cryptographically random TURN shared secret (at least 32 bytes). Generate the secret using your platform’s secure secret manager or a local cryptographic tool. Do not commit it.
3. Deploy coturn or another compatible TURN REST-credential provider separately. `turnserver.example.conf` is an illustrative template, not a deployed service. Its shared secret must match the connection service. Set real certificates, realm, external/private addresses where needed, quotas and firewall rules; deny relay access to private and loopback destinations to avoid creating a network pivot. Assess and configure TURN logs/retention independently.
4. Set `SHARING_DOMAIN` in your shell and launch the optional Caddy/relay compose configuration. Caddy obtains TLS for that domain. The compose file does **not** deploy TURN.
5. Verify HTTPS/WSS, and test over two genuinely different networks with a forced relay path before distribution. Check NAT, UDP and TCP/TLS TURN paths. The templates have not been deployed or verified against a real domain in this workspace.
6. Enter the origin in Still’s Screen sharing settings. Publish the operator identity, privacy practices and costs for users. No default free server is included.

Review hosting limits before public exposure. Rooms are capped, messages and concurrent sockets are bounded, and create attempts are rate-limited, but the supplied service is not a managed anti-abuse platform. Add appropriate infrastructure controls and operator authentication/provisioning if running a public multi-tenant service. A denial-of-service attack can still affect availability.

## Protocol

Connect `wss://<origin>/signal`. Native clients can omit Origin; browser Origin must equal `PUBLIC_ORIGIN`. Tokens are lowercase 32-digit hexadecimal random values. Credentials are sent over the protected WebSocket, not URL query parameters. Invitations use `https://<origin>/#room=...&invite=...`; the page removes the fragment immediately and retains it only in memory.

A native sender normally creates a room:

```json
{"type":"create","role":"sender","room":"32 random hex digits","owner":"private owner secret","invite":"separate invitation secret","allowRecording":false,"allowControl":false,"controlKind":"none"}
```

The server replies `ready` with role, capabilities and ICE servers. A viewer joins using `join`, room and invite. It receives `joined` with role `receiver`; the host receives `peer-joined`. Both messages include fresh ICE servers. Only one viewer is accepted. The private owner secret is absent from the invitation.

Legacy receiver-created rooms are supported by omitting role (default `receiver`). In that case the joining device is the sender. SDP offer is always sender-only and answer receiver-only, regardless of ownership. Candidate messages are validated before forwarding.

Only the sender may update `capabilities` (`allowRecording`, `allowControl`, `controlKind` of `touch`, `pointer`, or `none`). An iOS broadcaster always declares no control. The viewer sends recording notices only if the host opted in. Built-in consent flags cannot prevent external screen capture. Remote input itself travels through the peer’s encrypted `still-control` data channel and is validated again by the native host; the signaling service exposes no remote-input or command-execution endpoint.

`end` is accepted only from the room owner. Owner disconnection leaves a 90-second grace; reconnect with the same role/private owner/invite credentials to resume. The other peer receives `sender-away`/`sender-back` or `receiver-away`/`receiver-back`. A joining peer’s departure produces `peer-left`. Sessions expire after two hours. Process restart loses room state. No persistent identity or device directory is provided.

TURN credentials expire after three hours so they cover the two-hour room lifetime. They use the TURN REST HMAC-SHA1 convention with a server-only shared secret. The shared secret is never returned to a client. This is credential authentication, not a choice of media cipher; WebRTC negotiates its own DTLS-SRTP transport encryption.
