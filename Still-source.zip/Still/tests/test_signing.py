import datetime,os,pathlib,plistlib,subprocess,tempfile,unittest,uuid
ROOT=pathlib.Path(__file__).resolve().parents[1]
class SigningTests(unittest.TestCase):
    def run_fixture(self,bad_group=False,expired=False):
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp);(root/'bin').mkdir();security=root/'bin/security';security.write_text('#!/bin/sh\ncat "$4"\n');security.chmod(0o755)
            for suffix,name in [('', 'still-profile'),('.broadcast','still-broadcast-profile')]:
                profile={'UUID':str(uuid.uuid4()),'ExpirationDate':datetime.datetime(2020 if expired else 2030,1,1),'Entitlements':{'application-identifier':'ABCDE12345.com.example.still'+suffix,'com.apple.security.application-groups':[] if bad_group and suffix else ['group.com.example.still']}}
                (root/(name+'.mobileprovision')).write_bytes(plistlib.dumps(profile))
            env={**os.environ,'PATH':str(root/'bin')+':'+os.environ['PATH'],'STILL_PROFILES_DIRECTORY':str(root/'profiles'),'RUNNER_TEMP':str(root),'GITHUB_ENV':str(root/'github-env'),'APPLE_TEAM_ID':'ABCDE12345','BUNDLE_ID':'com.example.still','APP_GROUP':'group.com.example.still','EXPORT_METHOD':'release-testing'}
            result=subprocess.run(['python',str(ROOT/'scripts/prepare-signing.py')],cwd=root,env=env,capture_output=True,text=True)
            spec=(root/'project.signed.yml').read_text() if (root/'project.signed.yml').exists() else ''
            options=plistlib.loads((root/'Still-ExportOptions.plist').read_bytes()) if (root/'Still-ExportOptions.plist').exists() else {}
            return result,spec,options
    def test_both_targets_receive_distinct_profiles(self):
        result,spec,options=self.run_fixture();self.assertEqual(result.returncode,0,result.stderr);self.assertIn('StillBroadcastUpload:',spec);self.assertIn('STILL_APP_GROUP:',spec);self.assertEqual(set(options['provisioningProfiles']),{'com.example.still','com.example.still.broadcast'});self.assertEqual(len(set(options['provisioningProfiles'].values())),2)
    def test_missing_extension_group_is_rejected(self):
        result,_,options=self.run_fixture(bad_group=True);self.assertNotEqual(result.returncode,0);self.assertIn('BOTH',result.stderr);self.assertFalse(options)
    def test_expired_profile_is_rejected(self):
        result,_,_=self.run_fixture(expired=True);self.assertNotEqual(result.returncode,0);self.assertIn('expired',result.stderr)
