import importlib.util
from pathlib import Path
import stat
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('unpack_release', ROOT / 'scripts/unpack-release.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class ReleaseBundleTests(unittest.TestCase):
    def archive(self, folder, extras=(), prefix='Still/'):
        archive = folder / 'source.zip'
        with zipfile.ZipFile(archive, 'w') as output:
            for name in module.REQUIRED:
                output.writestr(prefix+name, "MARKETING_VERSION: '1.2.0'\n" if name == 'project.yml' else 'fixture\n')
            for name, data in extras:
                output.writestr(name, data)
        return archive

    def test_supplied_source_unpacks_and_preserves_build_entrypoint(self):
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary)/'project'
            archive = ROOT/'Still-source.zip'
            if not archive.exists(): archive = ROOT.parent/'Still-source.zip'
            if not archive.exists(): self.skipTest('Requires the separately uploaded source ZIP.')
            self.assertEqual(module.unpack(archive, destination), '2.0.0')
            self.assertTrue((destination/'scripts/build-ipa.sh').stat().st_mode & stat.S_IXUSR)
            self.assertTrue((destination/'Still/Services/ScreenSession.swift').exists())
            self.assertTrue((destination/'StillBroadcastUpload/SampleHandler.swift').exists())
            self.assertTrue((destination/'desktop/package-lock.json').exists())

    def test_flat_and_single_folder_archives_work(self):
        for prefix in ['', 'Still/']:
            with self.subTest(prefix=prefix), tempfile.TemporaryDirectory() as temporary:
                folder=Path(temporary)
                self.assertEqual(module.unpack(self.archive(folder, prefix=prefix),folder/'out'),'1.2.0')

    def test_unsafe_paths_and_case_collisions_are_rejected_before_writing(self):
        for path in ['Still/../outside', '/absolute', 'Still/folder\\outside', 'Still/C:/outside', 'Still/PROJECT.YML']:
            with self.subTest(path=path), tempfile.TemporaryDirectory() as temporary:
                folder=Path(temporary)
                with self.assertRaises(ValueError): module.unpack(self.archive(folder,[(path,'bad')]),folder/'out')
                self.assertFalse((folder/'out').exists())

    def test_symlink_entry_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary); archive=self.archive(folder)
            with zipfile.ZipFile(archive,'a') as output:
                link=zipfile.ZipInfo('Still/link');link.create_system=3;link.external_attr=(stat.S_IFLNK|0o777)<<16
                output.writestr(link,'/tmp')
            with self.assertRaises(ValueError):module.unpack(archive,folder/'out')

    def test_archive_with_missing_project_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary)
            with zipfile.ZipFile(folder/'source.zip','w') as output:output.writestr('Still/README.md','not a project')
            with self.assertRaises(ValueError):module.unpack(folder/'source.zip',folder/'out')

    def test_nonempty_directory_and_symlink_destination_are_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary);archive=self.archive(folder);destination=folder/'out';destination.mkdir();(destination/'keep').write_text('safe')
            with self.assertRaises(ValueError):module.unpack(archive,destination)
            self.assertEqual((destination/'keep').read_text(),'safe')
            target=folder/'elsewhere';target.mkdir();link=folder/'link';link.symlink_to(target,target_is_directory=True)
            with self.assertRaises(ValueError):module.unpack(archive,link)

if __name__ == '__main__': unittest.main()
