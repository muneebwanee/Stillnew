package com.muneebwanee.stillsender;
import android.content.Context;
import org.webrtc.*;
final class AndroidRtc {
    private static boolean initialized;
    static synchronized PeerConnectionFactory factory(Context context,EglBase egl){
        if(!initialized){PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(context.getApplicationContext()).setEnableInternalTracer(false).createInitializationOptions());initialized=true;}
        return PeerConnectionFactory.builder().setVideoEncoderFactory(new DefaultVideoEncoderFactory(egl.getEglBaseContext(),true,true)).setVideoDecoderFactory(new DefaultVideoDecoderFactory(egl.getEglBaseContext())).createPeerConnectionFactory();
    }
}
