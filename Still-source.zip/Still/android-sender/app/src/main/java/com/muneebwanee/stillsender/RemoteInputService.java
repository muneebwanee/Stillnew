package com.muneebwanee.stillsender;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import org.json.JSONObject;

/** Input is accepted only from the current user-approved screen-share session. No UI content is read. */
public final class RemoteInputService extends AccessibilityService {
    private static volatile RemoteInputService instance;
    private static volatile boolean sessionAllowed;
    private final Handler main=new Handler(Looper.getMainLooper());
    private long lastInput;
    public static boolean available(){return instance!=null;}
    public static void allowSession(boolean allowed){sessionAllowed=allowed;}
    public static void dispatch(JSONObject input){RemoteInputService service=instance;if(service!=null&&sessionAllowed)service.main.post(()->service.apply(input));}
    @Override protected void onServiceConnected(){instance=this;sessionAllowed=false;}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){}
    @Override public void onInterrupt(){sessionAllowed=false;}
    @Override public void onDestroy(){sessionAllowed=false;if(instance==this)instance=null;main.removeCallbacksAndMessages(null);super.onDestroy();}
    private static double coordinate(JSONObject value,String key)throws Exception{double n=value.getDouble(key);if(!Double.isFinite(n)||n<0||n>1)throw new IllegalArgumentException();return n;}
    private void apply(JSONObject value){
        if(!sessionAllowed||!"input".equals(value.optString("type")))return;
        long now=android.os.SystemClock.elapsedRealtime();if(now-lastInput<60)return;lastInput=now;
        try{
            String kind=value.getString("kind");
            if("key".equals(kind)){
                String key=value.getString("key");int action="back".equals(key)?GLOBAL_ACTION_BACK:"home".equals(key)?GLOBAL_ACTION_HOME:"recents".equals(key)?GLOBAL_ACTION_RECENTS:0;
                if(action!=0)performGlobalAction(action);return;
            }
            if(!"tap".equals(kind)&&!"swipe".equals(kind))return;
            android.util.DisplayMetrics metrics=new android.util.DisplayMetrics();
            ((android.view.WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(metrics);
            float x=(float)(coordinate(value,"x")*(metrics.widthPixels-1)),y=(float)(coordinate(value,"y")*(metrics.heightPixels-1));Path path=new Path();path.moveTo(x,y);
            long duration=80;
            if("swipe".equals(kind)){path.lineTo((float)(coordinate(value,"x2")*(metrics.widthPixels-1)),(float)(coordinate(value,"y2")*(metrics.heightPixels-1)));duration=Math.max(100,Math.min(1000,value.getLong("duration")));}
            dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,duration)).build(),null,null);
        }catch(Exception ignored){/* Invalid remote input is discarded. */}
    }
}
