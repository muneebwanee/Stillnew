package com.muneebwanee.stillsender;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.core.content.ContextCompat;

public final class MainActivity extends StillActivity {
    private EditText server,link;private TextView status;private CheckBox recording,control;private Spinner quality;private String selectedServer;private boolean updatesRegistered;
    private final BroadcastReceiver updates=new BroadcastReceiver(){public void onReceive(Context c,Intent i){status.setText(i.getStringExtra("message"));}};
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        ScrollView scroll=new ScrollView(this);LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);int pad=(int)(24*getResources().getDisplayMetrics().density);layout.setPadding(pad,pad*2,pad,pad);scroll.addView(layout);setContentView(scroll);
        layout.addView(text("still",26));TextView title=text("One screen.\nCloser together.",36);title.setPadding(0,pad,0,pad);layout.addView(title);
        layout.addView(text("Share your screen, or open an invitation to view another device.",16));
        status=text("Ready when you are.",14);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);layout.addView(status);
        addButton(layout,"Share this device",()->showShare());
        link=new EditText(this);link.setHint("Paste an invitation");link.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);link.setSingleLine(true);link.setSaveEnabled(false);layout.addView(link);
        addButton(layout,"View a device",()->{try{Invitation.parse(link.getText().toString());startActivity(new Intent(this,ReceiveActivity.class).putExtra("link",link.getText().toString()));}catch(Exception e){status.setText(e.getMessage());}});
        addButton(layout,"Share my invitation",()->{String invitation=ShareService.currentInvitation;if(invitation==null){status.setText("Start sharing first. Your invitation appears when the connection is ready.");return;}startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,invitation),"Share invitation"));});
        addButton(layout,"Stop sharing",()->{stopService(new Intent(this,ShareService.class));status.setText("Sharing stopped.");});
        addButton(layout,"Settings",()->showSettings());
        IntentFilter filter=new IntentFilter("com.muneebwanee.stillsender.UPDATE");ContextCompat.registerReceiver(this,updates,filter,"com.muneebwanee.stillsender.STATUS",null,ContextCompat.RECEIVER_NOT_EXPORTED);updatesRegistered=true;
        if(getIntent().getData()!=null)link.setText(getIntent().getData().toString());
    }
    private void showShare(){
        LinearLayout form=new LinearLayout(this);form.setPadding(40,16,40,8);form.setOrientation(LinearLayout.VERTICAL);
        server=new EditText(this);server.setSingleLine(true);server.setHint("https://your-connection-service");server.setText(getSharedPreferences("still",0).getString("server",""));server.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);form.addView(server);
        quality=new Spinner(this);quality.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Balanced · 720p","Sharper · 1080p","Lighter · 480p"}));form.addView(quality);
        recording=new CheckBox(this);recording.setText("Allow recording");form.addView(recording);
        control=new CheckBox(this);control.setText("Allow control for this session");form.addView(control);
        form.addView(text("Your entire screen will be shared. Notifications may be visible. Android shows an active sharing indicator and a Stop action.",14));
        new AlertDialog.Builder(this).setTitle("Share this device").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Choose screen",(d,w)->{
            try{android.net.Uri value=android.net.Uri.parse(server.getText().toString().trim());if(!"https".equals(value.getScheme())||value.getHost()==null||value.getUserInfo()!=null||value.getQuery()!=null||value.getFragment()!=null||(value.getPath()!=null&&!value.getPath().isEmpty()&&!"/".equals(value.getPath())))throw new IllegalArgumentException("Enter your HTTPS connection-service address.");selectedServer="https://"+value.getEncodedAuthority();getSharedPreferences("still",0).edit().putString("server",selectedServer).apply();
                if(control.isChecked()&&!RemoteInputService.available()){status.setText("Enable Still in Accessibility settings, then start a new share with Allow control.");new AlertDialog.Builder(this).setTitle("Allow remote control?").setMessage("Still uses Accessibility to perform taps, swipes, Back, Home and recent apps from your invited device. It does not read screen text. Control works only while a screen-share session with Allow control is active.").setNegativeButton("Cancel",null).setPositiveButton("Open Accessibility",(a,b)->startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))).show();return;}
                if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},43);else beginCapture();
            }catch(Exception e){status.setText(e.getMessage());}
        }).show();
    }
    private void beginCapture(){MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);Intent capture=android.os.Build.VERSION.SDK_INT>=34?manager.createScreenCaptureIntent(android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()):manager.createScreenCaptureIntent();startActivityForResult(capture,42);}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){super.onRequestPermissionsResult(request,permissions,grants);if(request==43&&selectedServer!=null)beginCapture();}
    private void showSettings(){new AlertDialog.Builder(this).setTitle("Settings").setItems(new String[]{"Privacy & terms","Remote control permissions","Wipe local data","About Still","Appearance"},(d,index)->{
        if(index==4){String[] choices={"System","Light","Dark"};new AlertDialog.Builder(this).setTitle("Appearance").setItems(choices,(a,b)->{getSharedPreferences("still",0).edit().putString("appearance",choices[b]).apply();recreate();}).show();}else if(index==0)showLegal();else if(index==1)startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));else if(index==2)new AlertDialog.Builder(this).setTitle("Wipe local data?").setMessage("Ends screen sharing and removes this app’s saved connection settings. Copies you exported stay where you saved them.").setNegativeButton("Cancel",null).setPositiveButton("Wipe",(a,b)->{stopService(new Intent(this,ShareService.class));RemoteInputService.allowSession(false);getSharedPreferences("still",0).edit().clear().apply();link.setText("");status.setText("Local data cleared.");}).show();else new AlertDialog.Builder(this).setTitle("Still").setMessage("Developed by muneebwanee\ngithub.com/muneebwanee\n\nLive screen sharing and control with your permission.").setPositiveButton("Done",null).show();}).setNegativeButton("Done",null).show();}
    private void showLegal(){try(java.io.InputStream input=getAssets().open("documents.json")){
        java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;while((count=input.read(buffer))!=-1)bytes.write(buffer,0,count);org.json.JSONObject docs=new org.json.JSONObject(bytes.toString("UTF-8"));String[] keys={"privacy","terms","eula","dataSafety","ncl","licenses"};String[] titles=new String[keys.length];for(int i=0;i<keys.length;i++)titles[i]=docs.getJSONObject(keys[i]).getString("title");
        new AlertDialog.Builder(this).setTitle("Privacy & terms").setItems(titles,(dialog,index)->{try{org.json.JSONObject doc=docs.getJSONObject(keys[index]);StringBuilder body=new StringBuilder(doc.getString("effective"));org.json.JSONArray sections=doc.getJSONArray("sections");for(int i=0;i<sections.length();i++){org.json.JSONObject section=sections.getJSONObject(i);body.append("\n\n").append(section.getString("heading")).append("\n\n").append(section.getString("body"));}ScrollView scroll=new ScrollView(this);TextView content=text(body.toString(),15);content.setPadding(32,16,32,16);content.setTextIsSelectable(true);scroll.addView(content);new AlertDialog.Builder(this).setTitle(doc.getString("title")).setView(scroll).setPositiveButton("Done",null).show();}catch(Exception error){status.setText("This document could not be opened.");}}).setNegativeButton("Done",null).show();
    }catch(Exception error){status.setText("Documents are missing from this build.");}}
    private TextView text(String value,int size){TextView view=new TextView(this);view.setText(value);view.setTextSize(size);view.setPadding(0,12,0,12);return view;}
    private void addButton(LinearLayout layout,String label,Runnable action){Button button=new Button(this);button.setText(label);button.setAllCaps(false);button.setMinHeight((int)(56*getResources().getDisplayMetrics().density));button.setOnClickListener(v->action.run());layout.addView(button);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=42)return;if(result!=RESULT_OK||data==null||selectedServer==null){status.setText("Screen capture was cancelled.");return;}String room=token(),owner=token(),invite=token();Intent service=new Intent(this,ShareService.class).putExtra("server",selectedServer).putExtra("room",room).putExtra("owner",owner).putExtra("invite",invite).putExtra("recording",recording.isChecked()).putExtra("control",control.isChecked()).putExtra("quality",quality.getSelectedItemPosition()).putExtra("capture",data);try{startForegroundService(service);status.setText("Preparing your invitation…");}catch(RuntimeException error){status.setText("Capture could not start. Keep Still open and try again.");}}
    private static String token(){return java.util.UUID.randomUUID().toString().replace("-","");}
    @Override protected void onDestroy(){if(updatesRegistered){unregisterReceiver(updates);updatesRegistered=false;}super.onDestroy();}
}
