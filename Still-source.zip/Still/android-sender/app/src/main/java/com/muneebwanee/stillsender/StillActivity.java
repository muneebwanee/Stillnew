package com.muneebwanee.stillsender;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
abstract class StillActivity extends Activity {
    @Override protected void attachBaseContext(Context base){String mode=base.getSharedPreferences("still",0).getString("appearance","System");if(!"System".equals(mode)){Configuration config=new Configuration(base.getResources().getConfiguration());config.uiMode=(config.uiMode&~Configuration.UI_MODE_NIGHT_MASK)|("Dark".equals(mode)?Configuration.UI_MODE_NIGHT_YES:Configuration.UI_MODE_NIGHT_NO);base=base.createConfigurationContext(config);}super.attachBaseContext(base);}
}
