package com.muneebwanee.stillsender;
import android.app.Activity;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import org.webrtc.*;
import okhttp3.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

public final class ReceiveActivity extends StillActivity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private final OkHttpClient http=new OkHttpClient.Builder().pingInterval(15,TimeUnit.SECONDS).build();
    private Invitation invitation;private WebSocket socket;private PeerConnectionFactory factory;private EglBase egl;private PeerConnection peer;private SurfaceViewRenderer renderer;private VideoTrack track;private DataChannel channel;
    private TextView status;private CheckBox control;private boolean active=true,remoteSet,allowed;private int attempt;private volatile int frameWidth=1,frameHeight=1;private float startX,startY;private long startTime;
    private final List<IceCandidate> pending=new ArrayList<>();
    private final VideoSink dimensions=frame->{frameWidth=frame.getRotatedWidth();frameHeight=frame.getRotatedHeight();};
    @Override public void onCreate(Bundle state){super.onCreate(state);
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setPadding(16,32,16,16);setContentView(layout);
        status=new TextView(this);status.setText("Connecting…");status.setPadding(16,16,16,16);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);layout.addView(status);
        egl=EglBase.create();factory=AndroidRtc.factory(this,egl);renderer=new SurfaceViewRenderer(this);renderer.init(egl.getEglBaseContext(),null);renderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);renderer.setEnableHardwareScaler(true);renderer.setBackgroundColor(android.graphics.Color.BLACK);renderer.setContentDescription("Live screen from your invited device");layout.addView(renderer,new LinearLayout.LayoutParams(-1,0,1));
        control=new CheckBox(this);control.setText("Control this device");control.setEnabled(false);layout.addView(control);renderer.setOnTouchListener((v,event)->touch(event));
        LinearLayout keys=new LinearLayout(this);for(String key:new String[]{"back","home","recents"}){Button button=new Button(this);button.setText(key);button.setAllCaps(false);button.setOnClickListener(v->sendInput(json("type","input","kind","key","key",key)));keys.addView(button,new LinearLayout.LayoutParams(0,-2,1));}layout.addView(keys);
        Button done=new Button(this);done.setText("Disconnect");done.setOnClickListener(v->finish());layout.addView(done);
        try{invitation=Invitation.parse(getIntent().getStringExtra("link"));connect();}catch(Exception e){status.setText("This invitation is incomplete.");}
    }
    private boolean touch(MotionEvent e){if(!control.isChecked()||!allowed)return false;
        if(e.getAction()==MotionEvent.ACTION_DOWN){float[] p=point(e.getX(),e.getY());if(p==null)return false;startX=p[0];startY=p[1];startTime=SystemClock.elapsedRealtime();return true;}
        if(e.getAction()==MotionEvent.ACTION_UP){float[] p=point(e.getX(),e.getY());if(p==null)return true;double distance=Math.hypot(p[0]-startX,p[1]-startY);if(distance<0.015)sendInput(json("type","input","kind","tap","x",p[0],"y",p[1]));else sendInput(json("type","input","kind","swipe","x",startX,"y",startY,"x2",p[0],"y2",p[1],"duration",Math.max(100,Math.min(1000,SystemClock.elapsedRealtime()-startTime))));return true;}return true;
    }
    private float[] point(float x,float y){double scale=Math.min((double)renderer.getWidth()/frameWidth,(double)renderer.getHeight()/frameHeight),w=frameWidth*scale,h=frameHeight*scale,px=(x-(renderer.getWidth()-w)/2)/w,py=(y-(renderer.getHeight()-h)/2)/h;if(!Double.isFinite(px)||!Double.isFinite(py)||px<0||px>1||py<0||py>1)return null;return new float[]{(float)px,(float)py};}
    private void sendInput(JSONObject value){if(control.isChecked()&&allowed&&channel!=null&&channel.state()==DataChannel.State.OPEN)channel.send(new DataChannel.Buffer(ByteBuffer.wrap(value.toString().getBytes(StandardCharsets.UTF_8)),false));}
    private void connect(){if(!active)return;closePeer();socket=http.newWebSocket(new Request.Builder().url(invitation.server+"/signal").build(),new WebSocketListener(){
        @Override public void onOpen(WebSocket ws,Response response){main.post(()->{if(socket==ws)send(json("type","join","room",invitation.room,"invite",invitation.invite));});}
        @Override public void onMessage(WebSocket ws,String text){main.post(()->{if(socket==ws&&active)handle(text);});}
        @Override public void onClosing(WebSocket ws,int code,String reason){ws.close(code,reason);}
        @Override public void onClosed(WebSocket ws,int code,String reason){main.post(()->{if(socket==ws)retry();});}
        @Override public void onFailure(WebSocket ws,Throwable error,Response response){main.post(()->{if(socket==ws)retry();});}
    });}
    private void retry(){if(!active)return;if(socket!=null){WebSocket old=socket;socket=null;old.cancel();}closePeer();if(attempt>=6){active=false;status.setText("Connection lost. Open a fresh invitation to try again.");return;}status.setText("Reconnecting…");main.postDelayed(this::connect,Math.min(10000,1000*(1<<attempt++)));}
    private void handle(String text){try{JSONObject m=new JSONObject(text);switch(m.getString("type")){
        case "joined":if(!"receiver".equals(m.optString("role")))throw new IllegalArgumentException();prepare(m.getJSONArray("iceServers"));capabilities(m);status.setText("Waiting for the other screen…");break;
        case "sender-back":prepare(m.getJSONArray("iceServers"));capabilities(m);status.setText("Reconnecting screen…");break;
        case "capabilities":capabilities(m);break;
        case "offer":if(peer==null)throw new IllegalStateException();final PeerConnection expected=peer;peer.setRemoteDescription(new Sdp(){@Override public void onSetSuccess(){main.post(()->{if(peer!=expected)return;remoteSet=true;for(IceCandidate c:pending)peer.addIceCandidate(c);pending.clear();peer.createAnswer(new Sdp(){@Override public void onCreateSuccess(SessionDescription answer){main.post(()->{if(peer!=expected)return;peer.setLocalDescription(new Sdp(){@Override public void onSetSuccess(){main.post(()->{if(peer==expected)send(json("type","answer","sdp",answer.description));});}},answer);});}},new MediaConstraints());});}},new SessionDescription(SessionDescription.Type.OFFER,m.getString("sdp")));break;
        case "candidate":IceCandidate c=new IceCandidate(m.isNull("sdpMid")?null:m.getString("sdpMid"),m.getInt("sdpMLineIndex"),m.getString("candidate"));if(peer!=null&&remoteSet)peer.addIceCandidate(c);else if(pending.size()<256)pending.add(c);break;
        case "sender-away":closePeer();status.setText("The other device disconnected. Waiting briefly…");break;
        case "ended":case "error":active=false;closePeer();if(socket!=null){socket.close(1000,"Ended");socket=null;}status.setText(m.optString("message","Sharing ended."));break;
    }}catch(Exception e){active=false;closePeer();if(socket!=null){socket.cancel();socket=null;}status.setText("Could not open this screen. Use a sharing invitation from the other device.");}}
    private void capabilities(JSONObject value){allowed=value.optBoolean("allowControl",false);control.setEnabled(allowed&&channel!=null&&channel.state()==DataChannel.State.OPEN);if(!allowed)control.setChecked(false);}
    private void prepare(JSONArray entries)throws JSONException{closePeer();List<PeerConnection.IceServer> servers=new ArrayList<>();for(int i=0;i<entries.length();i++){JSONObject e=entries.getJSONObject(i);JSONArray urls=e.getJSONArray("urls");List<String> list=new ArrayList<>();for(int j=0;j<urls.length();j++)list.add(urls.getString(j));PeerConnection.IceServer.Builder builder=PeerConnection.IceServer.builder(list);if(e.has("username"))builder.setUsername(e.getString("username"));if(e.has("credential"))builder.setPassword(e.getString("credential"));servers.add(builder.createIceServer());}PeerConnection.RTCConfiguration config=new PeerConnection.RTCConfiguration(servers);config.sdpSemantics=PeerConnection.SdpSemantics.UNIFIED_PLAN;final PeerConnection[] expected=new PeerConnection[1];
        peer=factory.createPeerConnection(config,new PeerConnection.Observer(){
            public void onSignalingChange(PeerConnection.SignalingState s){}public void onIceConnectionChange(PeerConnection.IceConnectionState s){}public void onIceConnectionReceivingChange(boolean r){}public void onIceGatheringChange(PeerConnection.IceGatheringState s){}
            public void onIceCandidate(IceCandidate c){main.post(()->{if(peer==expected[0])send(json("type","candidate","candidate",c.sdp,"sdpMid",c.sdpMid==null?JSONObject.NULL:c.sdpMid,"sdpMLineIndex",c.sdpMLineIndex));});}
            public void onIceCandidatesRemoved(IceCandidate[] c){}public void onAddStream(MediaStream s){}public void onRemoveStream(MediaStream s){}public void onRenegotiationNeeded(){}
            public void onDataChannel(DataChannel value){main.post(()->{if(peer!=expected[0]||!"still-control".equals(value.label())){value.close();return;}channel=value;value.registerObserver(new DataChannel.Observer(){public void onBufferedAmountChange(long previous){}public void onMessage(DataChannel.Buffer b){}public void onStateChange(){main.post(()->{if(channel==value)control.setEnabled(allowed&&value.state()==DataChannel.State.OPEN);});}});control.setEnabled(allowed&&value.state()==DataChannel.State.OPEN);});}
            public void onAddTrack(RtpReceiver receiver,MediaStream[] streams){MediaStreamTrack t=receiver.track();if(t instanceof VideoTrack)main.post(()->{if(peer!=expected[0])return;if(track!=null){track.removeSink(renderer);track.removeSink(dimensions);}track=(VideoTrack)t;track.addSink(renderer);track.addSink(dimensions);});}
            @Override public void onConnectionChange(PeerConnection.PeerConnectionState state){main.post(()->{if(peer!=expected[0]||!active)return;if(state==PeerConnection.PeerConnectionState.CONNECTED){attempt=0;status.setText("Live · "+(allowed?"Control available":"View only"));}else if(state==PeerConnection.PeerConnectionState.FAILED)retry();});}
        });expected[0]=peer;if(peer==null)throw new IllegalStateException();
    }
    private void send(JSONObject value){if(socket!=null)socket.send(value.toString());}
    private static JSONObject json(Object... p){JSONObject value=new JSONObject();try{for(int i=0;i<p.length;i+=2)value.put((String)p[i],p[i+1]);}catch(JSONException ignored){}return value;}
    private class Sdp implements SdpObserver{public void onCreateSuccess(SessionDescription s){}public void onSetSuccess(){}public void onCreateFailure(String e){main.post(()->status.setText("Could not prepare the screen."));}public void onSetFailure(String e){main.post(()->status.setText("Could not connect the screen."));}}
    private void closePeer(){allowed=false;control.setChecked(false);control.setEnabled(false);if(track!=null){track.removeSink(renderer);track.removeSink(dimensions);track=null;}if(channel!=null){channel.unregisterObserver();channel.close();channel.dispose();channel=null;}if(peer!=null){peer.close();peer.dispose();peer=null;}pending.clear();remoteSet=false;}
    @Override protected void onDestroy(){active=false;main.removeCallbacksAndMessages(null);if(socket!=null){socket.cancel();socket=null;}closePeer();renderer.release();factory.dispose();egl.release();http.dispatcher().executorService().shutdown();super.onDestroy();}
}
