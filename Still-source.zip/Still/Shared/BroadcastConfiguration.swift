import Foundation

struct BroadcastConfiguration: Codable {
    let origin: URL
    let room: String
    let owner: String
    let invite: String
    let allowRecording: Bool
    let created: Date
    var invitation: URL? {
        var parts = URLComponents(url: origin, resolvingAgainstBaseURL: false)
        parts?.path = "/"; parts?.fragment = "room=\(room)&invite=\(invite)"
        return parts?.url
    }
    static var group: String { Bundle.main.object(forInfoDictionaryKey: "StillAppGroup") as? String ?? "group.com.muneebwanee.still" }
    static var store: UserDefaults? { UserDefaults(suiteName: group) }
    static let configurationKey = "broadcast.configuration"
    static let stopKey = "broadcast.stop"
    static let statusKey = "broadcast.status"
    static func load() -> BroadcastConfiguration? {
        guard let data = store?.data(forKey: configurationKey), let config = try? JSONDecoder().decode(Self.self, from: data), Date().timeIntervalSince(config.created) < 7200 else { return nil }
        return config
    }
}
