const {contextBridge,ipcRenderer}=require('electron');
const invoke=(name,...args)=>ipcRenderer.invoke(name,...args);
contextBridge.exposeInMainWorld('still',{
 sources:()=>invoke('sources'),choose:(id,control)=>invoke('choose',id,control),revoke:()=>invoke('revoke'),
 open:(slot,origin)=>invoke('signal-open',slot,origin),send:(slot,value)=>invoke('signal-send',slot,value),close:slot=>invoke('signal-close',slot),
 input:value=>invoke('input',value),save:bytes=>invoke('save-recording',bytes),documents:()=>invoke('documents'),wipe:()=>invoke('wipe'),about:()=>invoke('about'),
 onSignal:callback=>ipcRenderer.on('signal',(_event,value)=>callback(value)),onInputError:callback=>ipcRenderer.on('input-error',()=>callback())
});
