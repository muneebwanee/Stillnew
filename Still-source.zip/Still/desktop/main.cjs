'use strict';
const {app,BrowserWindow,ipcMain,desktopCapturer,session,screen,systemPreferences,dialog,shell,powerSaveBlocker}=require('electron');
const {join}=require('node:path');const {readFile,rm,mkdir,writeFile}=require('node:fs/promises');const {WebSocket}=require('ws');const {validateInput}=require('./input.cjs');
let window,chosen,permissionUntil=0,inputBounds=null,allowInput=false,nut,inputBusy=false,lastInput=0,blocker;
const signals=new Map();const page=join(__dirname,'src','index.html');
function trusted(event){if(!window||event.sender!==window.webContents||event.senderFrame!==window.webContents.mainFrame)throw Error('Unavailable');}
function stopInput(){allowInput=false;inputBounds=null;}
async function automation(){if(!nut)nut=require('./native-input.cjs').loadNativeInput();return nut;}
function canInput(){return process.platform!=='linux'||(!process.env.WAYLAND_DISPLAY&&!!process.env.DISPLAY);}
function stopSignals(){for(const ws of signals.values())ws.close();signals.clear();stopInput();if(blocker!==undefined&&powerSaveBlocker.isStarted(blocker))powerSaveBlocker.stop(blocker);blocker=undefined;}
function setup(){
 session.defaultSession.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
 session.defaultSession.setDisplayMediaRequestHandler(async(request,callback)=>{
  if(!window||request.frame!==window.webContents.mainFrame||!chosen||Date.now()>permissionUntil){callback({});return;}
  const selected=chosen;chosen=null;permissionUntil=0;callback({video:selected});
 });
 ipcMain.handle('sources',async event=>{trusted(event);if(process.platform==='darwin'&&systemPreferences.getMediaAccessStatus('screen')!=='granted')await shell.openExternal('x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture');const sources=await desktopCapturer.getSources({types:['screen'],thumbnailSize:{width:320,height:180}});return sources.map(s=>({id:s.id,name:s.name,thumbnail:s.thumbnail.toDataURL()}));});
 ipcMain.handle('choose',async(event,id,control)=>{trusted(event);stopInput();const sources=await desktopCapturer.getSources({types:['screen']});const selected=sources.find(s=>s.id===id);if(!selected)throw Error('Choose an available screen.');let allowed=control===true&&canInput();if(allowed&&process.platform==='darwin'&&!systemPreferences.isTrustedAccessibilityClient(true))allowed=false;
  if(allowed){try{await automation();const display=screen.getAllDisplays().find(d=>String(d.id)===selected.display_id);if(!display)throw Error();inputBounds=display.bounds;allowInput=true;}catch{allowed=false;stopInput();}}
  chosen=selected;permissionUntil=Date.now()+15000;if(blocker===undefined)blocker=powerSaveBlocker.start('prevent-display-sleep');return {allowControl:allowed,controlKind:allowed?'pointer':'none'};
 });
 ipcMain.handle('revoke',event=>{trusted(event);stopInput();});
 ipcMain.handle('signal-open',(event,slot,origin)=>{trusted(event);if(!['share','view'].includes(slot))throw Error('Invalid session');const url=new URL(origin);if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash||!['/',''].includes(url.pathname))throw Error('Use an HTTPS connection service.');signals.get(slot)?.close();const ws=new WebSocket('wss://'+url.host+'/signal',{maxPayload:131072,handshakeTimeout:15000});signals.set(slot,ws);
  const emit=(state,message)=>{if(signals.get(slot)===ws&&!window.isDestroyed())window.webContents.send('signal',{slot,state,message});};
  ws.on('open',()=>emit('open'));ws.on('message',bytes=>{try{const value=JSON.parse(bytes);if(slot==='share'&&['peer-left','receiver-away','ended','error'].includes(value.type))stopInput();emit('message',value);}catch{}});ws.on('error',()=>emit('error'));ws.on('close',()=>{if(signals.get(slot)!==ws)return;if(slot==='share')stopInput();emit('close');});
 });
 ipcMain.handle('signal-send',(event,slot,message)=>{trusted(event);const ws=signals.get(slot);if(!ws||ws.readyState!==WebSocket.OPEN)return;const text=JSON.stringify(message);if(text.length>131072)throw Error('Message too large');ws.send(text);});
 ipcMain.handle('signal-close',(event,slot)=>{trusted(event);if(slot==='share')stopInput();const ws=signals.get(slot);signals.delete(slot);ws?.close();});
 ipcMain.handle('control-ready',async(event,id)=>{trusted(event);/* Re-arm only the screen locally selected for this session. */if(!inputBounds||!allowInput)return false;return true;});
 ipcMain.handle('input',async(event,value)=>{trusted(event);const input=validateInput(value),now=Date.now();if(!allowInput||!inputBounds||!input||inputBusy||now-lastInput<35)return;inputBusy=true;lastInput=now;const bounds=inputBounds;
  try{const {mouse,keyboard,Button,Key,Point}=await automation();mouse.config.autoDelayMs=0;keyboard.config.autoDelayMs=0;const position=(x,y)=>{let point={x:Math.round(bounds.x+x*(bounds.width-1)),y:Math.round(bounds.y+y*(bounds.height-1))};if(process.platform==='win32')point=screen.dipToScreenPoint(point);return new Point(point.x,point.y);};
   if(input.kind==='tap'){await mouse.setPosition(position(input.x,input.y));if(allowInput)await mouse.click(Button.LEFT);}
   else if(input.kind==='swipe'){await mouse.setPosition(position(input.x,input.y));if(!allowInput)return;await mouse.pressButton(Button.LEFT);try{for(let i=1;i<=12&&allowInput;i++){await mouse.setPosition(position(input.x+(input.x2-input.x)*i/12,input.y+(input.y2-input.y)*i/12));await new Promise(r=>setTimeout(r,input.duration/12));}}finally{await mouse.releaseButton(Button.LEFT);}}
   else if(input.kind==='key'){const aliases={ArrowLeft:'Left',ArrowRight:'Right',ArrowUp:'Up',ArrowDown:'Down',Escape:'Escape',Space:'Space'};const key=Key[aliases[input.key]||input.key];if(key!==undefined&&allowInput){await keyboard.pressKey(key);await keyboard.releaseKey(key);}}
   else if(input.kind==='text'){for(const character of input.text){if(!allowInput)break;await keyboard.type(character);}}
   else if(input.kind==='scroll'&&allowInput){if(input.delta>0)await mouse.scrollDown(input.delta);else await mouse.scrollUp(-input.delta);}
  }catch{stopInput();window.webContents.send('input-error');}finally{inputBusy=false;}
 });
 ipcMain.handle('save-recording',async(event,bytes)=>{trusted(event);if(!(bytes instanceof Uint8Array)||bytes.byteLength>512*1024*1024)throw Error('Recording is too large.');const result=await dialog.showSaveDialog(window,{defaultPath:'Still-'+Date.now()+'.webm',filters:[{name:'WebM video',extensions:['webm']}]});if(!result.canceled&&result.filePath){await writeFile(result.filePath,Buffer.from(bytes));return true;}return false;});
 ipcMain.handle('documents',async event=>{trusted(event);return JSON.parse(await readFile(join(__dirname,'resources','documents.json'),'utf8'));});
 ipcMain.handle('wipe',async event=>{trusted(event);stopSignals();await session.defaultSession.clearStorageData();await session.defaultSession.clearCache();});
 ipcMain.handle('about',event=>{trusted(event);return {platform:process.platform,control:canInput(),version:app.getVersion()};});
 window=new BrowserWindow({width:1000,height:820,minWidth:480,minHeight:620,backgroundColor:'#121412',title:'Still',webPreferences:{preload:join(__dirname,'preload.cjs'),contextIsolation:true,sandbox:true,nodeIntegration:false,webSecurity:true}});
 window.setMenuBarVisibility(false);window.webContents.setWindowOpenHandler(()=>({action:'deny'}));window.webContents.on('will-navigate',event=>event.preventDefault());window.on('close',()=>stopSignals());window.loadFile(page);
}
app.whenReady().then(setup);app.on('window-all-closed',()=>app.quit());
