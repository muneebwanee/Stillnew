'use strict';
// Only input primitives are wrapped; no image loading, clipboard or command execution API is exposed.
function createAdapter(native){
 native.setKeyboardDelay(0);native.setMouseDelay(0);
 return {
  Button:{LEFT:'left'},Point:class Point{constructor(x,y){this.x=x;this.y=y;}},
  Key:{Enter:'enter',Tab:'tab',Escape:'escape',Backspace:'backspace',Delete:'delete',Left:'left',Right:'right',Up:'up',Down:'down',Space:'space',PageUp:'pageup',PageDown:'pagedown'},
  mouse:{config:{},setPosition:p=>native.moveMouse(p.x,p.y),click:b=>native.mouseClick(b),pressButton:b=>native.mouseToggle('down',b),releaseButton:b=>native.mouseToggle('up',b),scrollDown:n=>native.scrollMouse(0,-n),scrollUp:n=>native.scrollMouse(0,n)},
  keyboard:{config:{},pressKey:k=>native.keyToggle(k,'down',[]),releaseKey:k=>native.keyToggle(k,'up',[]),type:text=>native.typeString(text)}
 };
}
function loadNativeInput(){const platform={darwin:'darwin',win32:'win32',linux:'linux'}[process.platform];if(!platform)throw Error('Native input is unavailable on this platform.');return createAdapter(require('@nut-tree-fork/libnut-'+platform));}
module.exports={loadNativeInput,createAdapter};
