'use strict';
// A deliberately small protocol. Neither IPC nor remote messages expose shell commands.
const keys=new Set(['Enter','Tab','Escape','Backspace','Delete','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space','PageUp','PageDown']);
function validateInput(value){
 if(!value||value.type!=='input')return null;
 const point=(x,y)=>Number.isFinite(x)&&Number.isFinite(y)&&x>=0&&x<=1&&y>=0&&y<=1;
 if(value.kind==='tap'&&point(value.x,value.y))return {kind:'tap',x:value.x,y:value.y};
 if(value.kind==='swipe'&&point(value.x,value.y)&&point(value.x2,value.y2)&&Number.isFinite(value.duration)&&value.duration>=100&&value.duration<=1000)return {kind:'swipe',x:value.x,y:value.y,x2:value.x2,y2:value.y2,duration:value.duration};
 if(value.kind==='key'&&keys.has(value.key))return {kind:'key',key:value.key};
 if(value.kind==='text'&&typeof value.text==='string'&&value.text.length>0&&value.text.length<=64&&!/[\x00-\x1f\x7f]/.test(value.text))return {kind:'text',text:value.text};
 if(value.kind==='scroll'&&Number.isFinite(value.delta)&&Math.abs(value.delta)<=5)return {kind:'scroll',delta:Math.trunc(value.delta)};
 return null;
}
function parseInvitation(text){const url=new URL(text.trim());if(url.protocol!=='https:'||url.username||url.password||url.search||!['','/'].includes(url.pathname))throw Error('Open a complete HTTPS invitation from Still.');const p=new URLSearchParams(url.hash.slice(1));const room=p.get('room'),invite=p.get('invite');if(!/^[a-f0-9]{32}$/.test(room)||!/^[a-f0-9]{32}$/.test(invite))throw Error('The invitation is incomplete.');return {origin:url.origin,room,invite};}
module.exports={validateInput,parseInvitation};
