# Still 2.0

Live screen sharing between your devices, developed by [muneebwanee](https://github.com/muneebwanee). Share this device, send its invitation, then choose View a device on the other screen. No account or developer analytics service. Source-available under the project-specific Still Non-Commercial License (NCL) 1.0.

| Platform | Share screen | View another screen | Control the host |
| --- | --- | --- | --- |
| iPhone / iPad · iOS 17+ | User-started ReplayKit broadcast | Foreground app | Can control approved Android/desktop hosts; iOS itself is view-only |
| Android · Android 10+ | System-approved MediaProjection foreground service | Native WebRTC viewer | Optional Accessibility taps, swipes, Back, Home, recent apps |
| macOS | Desktop capture, Screen Recording permission | Desktop viewer | Optional native pointer/navigation keys, Accessibility permission |
| Windows | Desktop capture | Desktop viewer | Normal desktop pointer/navigation keys; secure prompts remain protected |
| Linux | Desktop capture where the desktop portal permits | Desktop viewer | X11 only; no Wayland input |

Android and desktop have independent send/view connections and can do both simultaneously. iOS can broadcast while its main app views another screen, but its viewer stops when the app backgrounds. If both screens display each other, a mirror loop is expected. Desktop control is revoked after the viewer leaves or signaling fails; start a new share locally to grant it again.

Screen video only: no microphone or system audio. Capture and control always require the host’s permissions. Clipboard sync, file transfer, remote shells, administrator enrollment and unattended remote access are not implemented. OS lock, protected content, battery policy and connectivity can interrupt sessions. No claim of zero delay or universal background operation.

## Download and build

Upload the supplied **Still-source.zip** to the GitHub repository root. Put the supplied **build-release.yml** at **`.github/workflows/build-release.yml`**. Commit both, then open Actions → Build ZIP and release. The workflow tests and builds iOS, Android, Windows, macOS and Linux, then publishes build artifacts as a prerelease. Optional Android/desktop jobs can be disabled in Run workflow.

Default IPA builds are unsigned. iOS broadcasting needs a signed app and broadcast extension with the same registered App Group. Android APKs are debug-signed; desktop packages are unsigned and not notarized. These are test distributions, not completed App Store, Play Store or notarized releases. See [the upload/signing guide](GITHUB-RELEASE-SETUP.md).

**A connection service must be deployed once.** This source does not include a hosted public service. Both nearby and distant sessions use its HTTPS signaling address, and many networks need TURN. See [the server deployment guide](relay/README.md) and [screen-sharing guide](docs/SCREEN-SHARING.md). Enter the service address on each device that creates invitations. Viewers obtain it from the invitation.

## Interface and privacy

Simple Share and View home screen, system/light/dark appearance, native iOS themes, desktop accents, readable primary buttons, motion that respects Reduce Motion. Recording requires the host’s opt-in: iOS viewers save MP4 locally; desktop viewers save WebM to a chosen destination. Android viewing has no built-in recorder in this version.

Privacy Policy, Terms, Store EULA, Data Safety & Local Wipe, NCL 1.0 and required dependency notices are bundled offline. Wipe stops sessions and clears local settings and app-managed recordings. It cannot delete files you exported, other devices’ copies or OS records, and it does not revoke system permissions. An iOS broadcast stop request is checked by the extension; the system broadcast indicator is the immediate stop control.

The iOS app retains its video-link receiver and queue under **Video links & queue**. It accepts supported YouTube links through the official iframe player and HTTPS media through AVPlayer. It is not a Google Cast, AirPlay or Miracast receiver and does not appear in YouTube’s Cast menu.

## Develop

On a Mac with Xcode 16.4+ and XcodeGen:

```sh
brew install xcodegen
xcodegen generate
open Still.xcodeproj
```

Register both `com.muneebwanee.still` and `com.muneebwanee.still.broadcast` (or your own matching IDs), enable the same App Group for both, and choose your signing team for both targets. The project settings `STILL_BUNDLE_ID` and `STILL_APP_GROUP` can be changed together. A free personal team may not support the App Group entitlement; check your Apple account’s capabilities.

Android uses JDK 17, Gradle 8.13 and Android SDK 36:

```sh
cd android-sender
gradle assembleDebug lintDebug
```

Desktop uses Node 22.12+:

```sh
cd desktop
npm ci
npm start
npm run dist -- --publish never
```

On Linux, install the runtime X11 libraries needed by Electron/libnut; use an X11 session for control. On macOS, grant Screen Recording and Accessibility when needed, then restart the sharing session. Windows input does not cross UAC secure desktops or elevate privileges.

## Validation

```sh
node --test tests/remote.test.mjs tests/documents.test.mjs desktop/test/*.test.cjs
(cd relay && npm ci && npm test)
python -m unittest discover -s tests -p 'test_*.py'
swift test --package-path Packages/ReceiverCore  # Mac / Swift toolchain
```

Browser tests in `tests/desktop-browser.cjs` exercise simultaneous bidirectional WebRTC and encrypted data-channel control delivery using explicit canvas/native-input fixtures. `tests/electron-smoke.cjs` checks the real Electron sandboxed runtime and offline pages. Native capture, actual remote input, Apple signing and physical-device behavior still require the device matrix in [VALIDATION](docs/VALIDATION.md). See that file for what was actually run locally; source availability is not a production certification.
